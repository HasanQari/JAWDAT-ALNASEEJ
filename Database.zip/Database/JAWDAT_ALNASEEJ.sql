-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Mar 27, 2021 at 10:11 AM
-- Server version: 5.7.24
-- PHP Version: 7.2.19

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db1`
--
CREATE DATABASE IF NOT EXISTS `db1` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `db1`;

-- --------------------------------------------------------

--
-- Table structure for table `typicms_blocks`
--

CREATE TABLE `typicms_blocks` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` json NOT NULL,
  `body` json NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `typicms_files`
--

CREATE TABLE `typicms_files` (
  `id` int(10) UNSIGNED NOT NULL,
  `folder_id` int(10) UNSIGNED DEFAULT NULL,
  `type` enum('a','v','d','i','o','f') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `path` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `extension` varchar(8) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mimetype` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `width` int(10) UNSIGNED DEFAULT NULL,
  `height` int(10) UNSIGNED DEFAULT NULL,
  `filesize` int(10) UNSIGNED DEFAULT NULL,
  `position` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `description` json NOT NULL,
  `alt_attribute` json NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `typicms_history`
--

CREATE TABLE `typicms_history` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `historable_id` int(10) UNSIGNED NOT NULL,
  `historable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `icon_class` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `locale` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `historable_table` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `action` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `old` json NOT NULL,
  `new` json NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `typicms_history`
--

INSERT INTO `typicms_history` (`id`, `historable_id`, `historable_type`, `user_id`, `title`, `icon_class`, `locale`, `historable_table`, `action`, `old`, `new`, `created_at`, `updated_at`) VALUES
(1, 1, 'TypiCMS\\Modules\\Users\\Models\\User', NULL, 'Dev Q', 'fa-plus-circle', NULL, 'users', 'created', '[]', '{\"id\": 1, \"email\": \"test@test.com\", \"activated\": 1, \"api_token\": \"23d4c0b0-f6e1-44da-8c65-2a92a2192a1f\", \"last_name\": \"Q\", \"superuser\": 1, \"created_at\": \"2021-01-20 11:54:15\", \"first_name\": \"Dev\", \"updated_at\": \"2021-01-20 11:54:15\", \"email_verified_at\": \"2021-01-20T11:54:15.542048Z\"}', '2021-01-20 08:54:15', '2021-01-20 08:54:15'),
(2, 1, 'TypiCMS\\Modules\\Users\\Models\\User', 1, 'Dev Q', 'fa-edit', NULL, 'users', 'updated', '{\"password\": \"$2y$10$IHYFpioVx6nnH2EqXfF/reVx83dC4TAXJu0cjghYOw9eCMkQdAaYi\", \"updated_at\": \"2021-01-20 11:54:15\"}', '{\"password\": \"$2y$10$eODMnJlI54acPDluiCWlVuObtGaZgZ3q6xb3tg6KE66RtrvtekEum\", \"updated_at\": \"2021-01-20 12:01:28\"}', '2021-01-20 09:01:28', '2021-01-20 09:01:28'),
(3, 1, 'TypiCMS\\Modules\\Pages\\Models\\Page', 1, 'Home', 'fa-edit', NULL, 'pages', 'updated', '{\"body\": {\"en\": \"<h1>Home</h1>\"}, \"updated_at\": \"2021-01-20 11:53:43\"}', '{\"body\": {\"en\": \"<h1>Home</h1>\\r\\n\\r\\n<p>hello world !</p>\"}, \"updated_at\": \"2021-01-20 12:02:19\"}', '2021-01-20 09:02:19', '2021-01-20 09:02:19');

-- --------------------------------------------------------

--
-- Table structure for table `typicms_menulinks`
--

CREATE TABLE `typicms_menulinks` (
  `id` int(10) UNSIGNED NOT NULL,
  `menu_id` int(10) UNSIGNED NOT NULL,
  `page_id` int(10) UNSIGNED DEFAULT NULL,
  `parent_id` int(10) UNSIGNED DEFAULT NULL,
  `image_id` int(10) UNSIGNED DEFAULT NULL,
  `position` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `target` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `class` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `icon_class` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `has_categories` tinyint(1) DEFAULT NULL,
  `status` json NOT NULL,
  `title` json NOT NULL,
  `url` json NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `typicms_menulinks`
--

INSERT INTO `typicms_menulinks` (`id`, `menu_id`, `page_id`, `parent_id`, `image_id`, `position`, `target`, `class`, `icon_class`, `has_categories`, `status`, `title`, `url`, `created_at`, `updated_at`) VALUES
(1, 1, 1, NULL, NULL, 1, NULL, NULL, NULL, 0, '{\"en\": 1, \"fr\": 1, \"nl\": 1}', '{\"en\": \"Home\", \"fr\": \"Accueil\", \"nl\": \"Home\"}', '{\"en\": null, \"fr\": null, \"nl\": null}', '2021-01-20 08:53:43', '2021-01-20 08:53:43'),
(2, 1, 2, NULL, NULL, 2, NULL, NULL, NULL, 0, '{\"en\": 1, \"fr\": 1, \"nl\": 1}', '{\"en\": \"Contact\", \"fr\": \"Contact\", \"nl\": \"Contact\"}', '{\"en\": null, \"fr\": null, \"nl\": null}', '2021-01-20 08:53:43', '2021-01-20 08:53:43'),
(3, 2, 2, NULL, NULL, 1, NULL, NULL, NULL, 0, '{\"en\": 1, \"fr\": 1, \"nl\": 1}', '{\"en\": \"Contact\", \"fr\": \"Contact\", \"nl\": \"Contact\"}', '{\"en\": null, \"fr\": null, \"nl\": null}', '2021-01-20 08:53:43', '2021-01-20 08:53:43'),
(4, 3, NULL, NULL, NULL, 1, '_blank', 'btn-facebook', 'fa fa-facebook fa-fw', 0, '{\"en\": 1, \"fr\": 1, \"nl\": 1}', '{\"en\": \"Facebook\", \"fr\": \"Facebook\", \"nl\": \"Facebook\"}', '{\"en\": \"https://www.facebook.com\", \"fr\": \"https://www.facebook.com\", \"nl\": \"https://www.facebook.com\"}', '2021-01-20 08:53:43', '2021-01-20 08:53:43'),
(5, 3, NULL, NULL, NULL, 2, NULL, NULL, 'fa fa-linkedin fa-fw', 0, '{\"en\": 1, \"fr\": 1, \"nl\": 1}', '{\"en\": \"LinkedIn\", \"fr\": \"LinkedIn\", \"nl\": \"LinkedIn\"}', '{\"en\": \"https://www.linkedin.com\", \"fr\": \"https://www.linkedin.com\", \"nl\": \"https://www.linkedin.com\"}', '2021-01-20 08:53:43', '2021-01-20 08:53:43'),
(6, 3, NULL, NULL, NULL, 3, '_blank', 'btn-twitter', 'fa fa-twitter fa-fw', 0, '{\"en\": 1, \"fr\": 1, \"nl\": 1}', '{\"en\": \"Twitter\", \"fr\": \"Twitter\", \"nl\": \"Twitter\"}', '{\"en\": \"https://twitter.com\", \"fr\": \"https://twitter.com\", \"nl\": \"https://twitter.com\"}', '2021-01-20 08:53:43', '2021-01-20 08:53:43'),
(7, 3, NULL, NULL, NULL, 4, NULL, NULL, 'fa fa-instagram fa-fw', 0, '{\"en\": 1, \"fr\": 1, \"nl\": 1}', '{\"en\": \"Instagram\", \"fr\": \"Instagram\", \"nl\": \"Instagram\"}', '{\"en\": \"https://www.instagram.com\", \"fr\": \"https://www.instagram.com\", \"nl\": \"https://www.instagram.com\"}', '2021-01-20 08:53:43', '2021-01-20 08:53:43'),
(8, 3, NULL, NULL, NULL, 5, NULL, NULL, 'fa fa-youtube-play fa-fw', 0, '{\"en\": 1, \"fr\": 1, \"nl\": 1}', '{\"en\": \"YouTube\", \"fr\": \"YouTube\", \"nl\": \"YouTube\"}', '{\"en\": \"https://www.youtube.com\", \"fr\": \"https://www.youtube.com\", \"nl\": \"https://www.youtube.com\"}', '2021-01-20 08:53:43', '2021-01-20 08:53:43'),
(9, 4, 3, NULL, NULL, 0, NULL, NULL, NULL, 0, '{\"en\": 1, \"fr\": 1, \"nl\": 1}', '{\"en\": \"Terms and conditions\", \"fr\": \"Conditions générales\", \"nl\": \"Algemene Voorwaarden\"}', '{\"en\": null, \"fr\": null, \"nl\": null}', '2021-01-20 08:53:43', '2021-01-20 08:53:43'),
(10, 4, 4, NULL, NULL, 0, NULL, NULL, NULL, 0, '{\"en\": 1, \"fr\": 1, \"nl\": 1}', '{\"en\": \"Privacy policy\", \"fr\": \"Charte vie privée\", \"nl\": \"Privacyverklaring\"}', '{\"en\": null, \"fr\": null, \"nl\": null}', '2021-01-20 08:53:43', '2021-01-20 08:53:43'),
(11, 4, 5, NULL, NULL, 0, NULL, NULL, NULL, 0, '{\"en\": 1, \"fr\": 1, \"nl\": 1}', '{\"en\": \"Cookie policy\", \"fr\": \"Politique des cookies\", \"nl\": \"Cookieverklaring\"}', '{\"en\": null, \"fr\": null, \"nl\": null}', '2021-01-20 08:53:43', '2021-01-20 08:53:43');

-- --------------------------------------------------------

--
-- Table structure for table `typicms_menus`
--

CREATE TABLE `typicms_menus` (
  `id` int(10) UNSIGNED NOT NULL,
  `image_id` int(10) UNSIGNED DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `class` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` json NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `typicms_menus`
--

INSERT INTO `typicms_menus` (`id`, `image_id`, `name`, `class`, `status`, `created_at`, `updated_at`) VALUES
(1, NULL, 'main', NULL, '{\"en\": \"1\", \"fr\": \"1\", \"nl\": \"1\"}', '2021-01-20 08:53:43', '2021-01-20 08:53:43'),
(2, NULL, 'footer', NULL, '{\"en\": \"1\", \"fr\": \"1\", \"nl\": \"1\"}', '2021-01-20 08:53:43', '2021-01-20 08:53:43'),
(3, NULL, 'social', NULL, '{\"en\": \"1\", \"fr\": \"1\", \"nl\": \"1\"}', '2021-01-20 08:53:43', '2021-01-20 08:53:43'),
(4, NULL, 'legal', NULL, '{\"en\": 1, \"fr\": 1, \"nl\": 1}', '2021-01-20 08:53:43', '2021-01-20 08:53:43');

-- --------------------------------------------------------

--
-- Table structure for table `typicms_migrations`
--

CREATE TABLE `typicms_migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `typicms_migrations`
--

INSERT INTO `typicms_migrations` (`id`, `migration`, `batch`) VALUES
(1, '2012_12_06_225921_create_users_table', 1),
(2, '2012_12_06_225922_create_password_resets_table', 1),
(3, '2013_08_29_174626_create_pages_table', 1),
(4, '2013_09_03_084147_create_menus_tables', 1),
(5, '2013_09_03_084148_create_menulinks_tables', 1),
(6, '2013_10_29_224632_create_settings_table', 1),
(7, '2014_02_13_013804_create_tags_table', 1),
(8, '2014_02_28_223553_create_translations_table', 1),
(9, '2014_05_09_110000_create_files_table', 1),
(10, '2014_06_19_090602_create_blocks_table', 1),
(11, '2014_11_03_151402_create_history_table', 1),
(12, '2017_05_01_172100_create_model_has_files_table', 1),
(13, '2017_05_22_132900_create_page_sections_table', 1),
(14, '2021_01_20_115243_create_permission_tables', 1);

-- --------------------------------------------------------

--
-- Table structure for table `typicms_model_has_files`
--

CREATE TABLE `typicms_model_has_files` (
  `file_id` int(10) UNSIGNED NOT NULL,
  `model_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint(20) UNSIGNED NOT NULL,
  `position` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `typicms_pages`
--

CREATE TABLE `typicms_pages` (
  `id` int(10) UNSIGNED NOT NULL,
  `image_id` int(10) UNSIGNED DEFAULT NULL,
  `position` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `parent_id` int(10) UNSIGNED DEFAULT NULL,
  `private` tinyint(1) NOT NULL DEFAULT '0',
  `is_home` tinyint(1) NOT NULL DEFAULT '0',
  `redirect` tinyint(1) NOT NULL DEFAULT '0',
  `title` json NOT NULL,
  `slug` json NOT NULL,
  `uri` json NOT NULL,
  `body` json NOT NULL,
  `status` json NOT NULL,
  `meta_keywords` json NOT NULL,
  `meta_description` json NOT NULL,
  `css` text COLLATE utf8mb4_unicode_ci,
  `js` text COLLATE utf8mb4_unicode_ci,
  `module` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `template` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `typicms_pages`
--

INSERT INTO `typicms_pages` (`id`, `image_id`, `position`, `parent_id`, `private`, `is_home`, `redirect`, `title`, `slug`, `uri`, `body`, `status`, `meta_keywords`, `meta_description`, `css`, `js`, `module`, `template`, `created_at`, `updated_at`) VALUES
(1, NULL, 1, NULL, 0, 1, 0, '{\"en\": \"Home\", \"fr\": \"Accueil\", \"nl\": \"Home\"}', '{\"en\": null, \"fr\": null, \"nl\": null}', '[]', '{\"en\": \"<h1>Home</h1>\\r\\n\\r\\n<p>hello world !</p>\", \"fr\": \"<h1>Accueil</h1>\", \"nl\": \"<h1>Home</h1>\"}', '{\"en\": 1, \"fr\": 1, \"nl\": 1}', '{\"en\": null, \"fr\": null, \"nl\": null}', '{\"en\": null, \"fr\": null, \"nl\": null}', NULL, NULL, NULL, 'home', '2021-01-20 08:53:43', '2021-01-20 09:02:19'),
(2, NULL, 2, NULL, 0, 0, 0, '{\"en\": \"Contact\", \"fr\": \"Contact\", \"nl\": \"Contact\"}', '{\"en\": \"contact\", \"fr\": \"contact\", \"nl\": \"contact\"}', '{\"en\": \"contact\", \"fr\": \"contact\", \"nl\": \"contact\"}', '{\"en\": \"<h1>Contact</h1>\", \"fr\": \"<h1>Contact</h1>\", \"nl\": \"<h1>Contact</h1>\"}', '{\"en\": 1, \"fr\": 1, \"nl\": 1}', '{\"en\": null, \"fr\": null, \"nl\": null}', '{\"en\": null, \"fr\": null, \"nl\": null}', NULL, NULL, NULL, NULL, '2021-01-20 08:53:43', '2021-01-20 08:53:43'),
(3, NULL, 3, NULL, 0, 0, 0, '{\"en\": \"Terms and Conditions\", \"fr\": \"Conditions générales\", \"nl\": \"Algemene Voorwaarden\"}', '{\"en\": \"terms-and-conditions\", \"fr\": \"conditions-generales\", \"nl\": \"algemene-voorwaarden\"}', '{\"en\": \"terms-and-conditions\", \"fr\": \"conditions-generales\", \"nl\": \"algemene-voorwaarden\"}', '{\"en\": \"<h1>Disclaimer</h1><p>The use of our website always goes hand in hand with some rights and obligations. These are defined in our Terms of Sale, in our Privacy Policy, in our Cookie Statement and in the present Disclaimer (together, the “Terms and Conditions”).</p><p>The Terms and Conditions apply both to us, [X], as to you, the user. By using our website, you expressly acknowledge and accept the exclusive application of our Terms and Conditions and you expressly renounce your right to invoke your own terms and conditions.</p><p>We may deviate from these Terms and Conditions in some exceptional situations, but only to the extent that the deviations are accepted by each party and stated explicitly in writing. These deviations only replace or supplement the clauses to which they relate. They shall not affect the application of any other provisions of these Terms and Conditions.</p><h2>1. Who we are</h2><p>The website URL (hereafter: the “Website”) is an initiative of:</p><p>(naam en rechtsvorm onderneming) (hereafter: “[X]” and “We”)<br />(Adres maatschappelijke zetel)<br />(Postcode + gemeente/stad)<br />(Land)<br />VAT BE (ondernemingsnummer)<br />Email:<br />Phone:</p><p>Feel free to contact us should you have further questions or remarks. We promise to reply soon!</p><h2>2. Our Website</h2><h3>2.1 Proper functioning, safety and accessibility</h3><p>You can rest assured; we offer a user-friendly Website that is safe for every user. We take all reasonable and necessary measures to ensure the proper functioning, safety and accessibility of our Website. Yet we cannot give you an absolute guarantee on this matter. We are bound by an obligation of means only.</p><p>Any use of the Website is entirely at your own risk. We are not liable for damages resulting from malfunctions, interruptions, defects, harmful elements or other problems on or within our website, regardless of the existence of force majeure or other extraneous events.</p><p>We have the right to restrict and/or interrupt fully or partially the access to our Website, at any time and without prior warning. We will only take such measures if this is justified by the circumstances, without this being in any way a condition to be covered.</p><h3>2.2 Content on our Website</h3><p>We largely determine which content is available on our Website. We apply great care in this respect and make every effort to provide high quality information. We therefore take all necessary steps to keep our Website as complete, accurate and current as possible, even when the information is provided by third parties. We are always permitted to change, add or delete the content on our Website.</p><p>Despite our considerable attention, we are not able to guarantee the quality of the information available on our Website. It is possible that the information is not correct, not sufficiently accurate and/or not useful. We are not liable for (direct and indirect) damages which the user may suffer as a result of the information on our Website.</p><p>We ask you to notify us as soon as possible if you notice the content on our Website violates applicable laws and/or third party rights or is simply not acceptable. We will then take all the appropriate measures, which can include the partial or total removal of the information.</p><p>Our Website contains content that can be downloaded. You understand and agree that every download from our Website is at your own risk and that damages resulting from loss of data or damage to the computer system are your entire and sole responsibility.</p><h3>2.3 What we expect from you as a User</h3><p>The user bears some responsibility for the way we offer our Website. This means that you should refrain from acts that have a deleterious impact on the proper operation and security of the Website or on its use. For example, the Website cannot be used to circumvent our business model and/or to gather information from other users.</p><p>It is therefore forbidden to distribute content via our Website that (may) damage(s) other users of the Website. We may think at the spread of malicious software, computer viruses, malware, worms, trojans and cancelbots. The proliferation of unsolicited and/or commercial messages via the Website, such as junk mail, spam and chain letters, is also targeted.</p><p>We reserve the right to take all necessary (judicial and extrajudicial) actions that may offer appropriate remedies to the affected parties. The user is solely responsible for all actions exerted on the Website that cause damages to the Website and/or to other users. If this occurs, the user has the obligation to keep [X] harmless and indemnified from all claims that may arise.</p><h2>3. Links to other websites</h2><p>Our Website may contain or provide hyperlinks or pointed to other websites and/or electronic communication portals maintained by third parties or may provide third party content on our Website by framing or other methods. Such a reference being made on our Website does not mean that there is any connection between our Website and these third-party websites nor that we (implicitly) agree with the content of those sites.</p><p>We do not guarantee or assume any liability for the accuracy, legality, completeness or quality of the content of external websites linked to on our Website or of other electronic communications portals that are not under our actual control. These references are therefore to click at your own risk and responsibility. We are not liable for any damage resulting therefrom.</p><p>These external websites do not offer the same guarantees as we do. We therefor recommend you to carefully read the terms and conditions and privacy statement of these other websites.</p><h2>4. Intellectual Property Rights</h2><p>Creativity deserves protection; so does our Website and its content. Such protection is provided by intellectual property rights and is entitled to all parties, i.e. [X] and third parties. Content means the very broad category of photos, video, audio, text, ideas, notes, drawings, articles, et cetera. This content is protected by copyright, software rights, database rights, designs and models rights, and other applicable (intellectual property) rights. The technical nature of our Website is protected by copyright and by the rights on software and databases. Each trade name that we use on our Website is protected by trademark law.</p><p>Each user receives a limited right to access, use and display our Website and its content. This right is granted in a non-exclusive and non-transferable manner and can only be used within a personal, non-commercial context. We ask our users not to create nor to bring changes to the intellectual property rights as described in this article without the consent of the owner. [X] attaches great importance to its intellectual property rights and has taken all possible measures to ensure its protection. We will take legal actions against any infringement of existing intellectual property rights.</p><h2>5. Processing of personal data</h2><p>The personal information you provide is necessary for a good service. Entering incorrect or false personal data is considered a violation of our Terms and Conditions. User’s personal data are exclusively processed in accordance with the applicable Privacy Policy which can be consulted via our Website.</p><h2>6. General provisions</h2><p>We reserve the right to change, limit or discontinue our Website and related services at any time and to any extent. We may do so without noticing the user. This does not give rise to any form of compensation.</p><p>These Terms and Conditions shall be exclusively governed by and interpreted in accordance with Belgian law. Any dispute arising under or relating to the services of [X] shall come under the jurisdiction of the competent court of the judicial district [XXX].</p><p>If a provision of these Terms and Conditions is deemed invalid, the invalidity of such provision shall not affect the validity and enforceability of the remaining provisions of these Terms and Conditions, which shall remain in full force and effect. We retain the right to propose a valid modification of the disputed clause(s).</p>\", \"fr\": \"<h1>Conditions Générales</h1><p>L’utilisation de notre site internet est assortie des droits et obligations mentionnées explicitement sur notre le site mais aussi des droits et obligations définis dans le présent disclaimer ainsi que dans nos conditions générales de vente et dans notre charte vie privée. L’ensemble de ces textes constitue nos «&nbsp;Conditions Générales».</p><p>Ces Conditions Générales s’appliquent aussi bien à nous qu’à vous. En utilisant notre site internet, vous reconnaissez et acceptez explicitement l’application de nos Conditions Générales, à l’exclusion de Conditions Générales propres.</p><p>Il peut exceptionnellement être dérogé aux dispositions des Conditions Générales dans la mesure où ces dérogations ont fait l’objet d’un accord écrit entre les parties. Ces dérogations peuvent consister en la modification, l’ajout ou la suppression des clauses auxquelles elles se rapportent et n’ont aucune incidence sur l’application des autres dispositions des Conditions Générales.</p><h2>1.&nbsp;Qui sommes-nous&nbsp;?</h2><p>Le site internet [URL] est une initiative de&nbsp;:</p><p>    NOM DE L’ENTREPRISE + FORME JURIDIQUE<br />    ADRESSE<br />    Numéro d’entreprise (TVA-BE)&nbsp;:<br />    E-mail&nbsp;:<br />    Téléphone&nbsp;:</p><p>N’hésitez pas à nous contacter si vous avez des questions ou des remarques, nous promettons une réponse rapide.</p><h2>2.&nbsp;Notre site</h2><h3>2.1 Bon fonctionnement, sécurité et accessibilité</h3><p>Nous prenons toutes les mesures raisonnables et nécessaires pour assurer le bon fonctionnement, la sécurité et l’accessibilité de notre site. Toutefois, nous ne pouvons pas offrir de garantie d’opérabilité absolue et il faut dès lors considérer nos actions comme étant couvertes par une obligation de moyen.</p><p>Toute utilisation du site se fait toujours aux propres risques de l’utilisateur. Ainsi, nous ne sommes pas responsables des dommages pouvant résulter de possibles dysfonctionnements, interruptions, défauts ou encore d’éléments nuisibles présents sur le site, indépendamment de l’existence d’un cas de force majeure ou d’une cause étrangère.</p><p>Nous nous réservons le droit de restreindre l’accès à notre site ou d’interrompre son fonctionnement à tout moment, sans obligation de notification préalable. Ceci, en principe, seulement si les circonstances de l’espèce le justifient, mais il ne s’agit pas là d’une condition absolue.</p><h3>2.2. Contenu du site</h3><p>[X] détermine en grande partie le contenu de son site et prend grand soin des informations présentes sur celui-ci. [X] prend toutes les mesures possibles pour maintenir son site aussi complet, précis et à jour que possible, même lorsque les informations présentes sur celui-ci sont fournies par des tiers. [X] se réserve le droit de modifier, compléter ou supprimer à tout moment le site et son contenu.</p><p>[X] ne peut pas offrir de garantie absolue concernant la qualité de l’information présente sur son site. Il est donc possible que cette information ne soit pas toujours complète, exacte, suffisamment précise et/ou à jour. Par conséquent, [X] ne pourra pas être tenue responsable des dommages, directs et indirects, que l’utilisateur subirait de par l’information présente sur le site.</p><p>Si certains contenus sur le site sont en violation avec les lois applicables et/ou avec les droits des tiers et/ou tout simplement seraient contraires à la morale, nous vous demandons de nous en informer le plus rapidement possible afin que nous puissions prendre des mesures appropriées. [X] pourra notamment procéder à la suppression partielle ou totale desdites informations.</p><p>Le site contient du contenu téléchargeable. Tout téléchargement à partir du site a toujours lieu aux propres risques de l’utilisateur. [X] ne pourra en aucun cas être tenue responsable des éventuels dommages, directs et indirects, découlant de ces téléchargements, tels qu’une perte de données ou un endommagement du système informatique de l’utilisateur, qui relèvent entièrement et exclusivement de la responsabilité de l’utilisateur.</p><p>Concernant plus spécifiquement les prix et les informations sur nos produits figurant sur le site, une réserve s’applique pour les fautes formelles manifestes, comme des erreurs de frappe. L’utilisateur ne peut en aucun cas se prévaloir de l’existence d’un contrat avec [X] basé sur de telles foutes.</p><h3>2.3 Ce que nous attendons de l’utilisateur</h3><p>En tant qu’utilisateur, vous avez une certaine responsabilité quant au bon fonctionnement du site. Vous devez en tout temps vous abstenir de poser des actes susceptibles de nuire au bon fonctionnement et à la sécurité du site et de son utilisation. Par exemple, le site ne peut être utilisé dans le but de contourner notre Business Model et/ou pour récolter des informations sur d’autres utilisateurs.</p><p>Il est notamment interdit d’utiliser le Site pour diffuser du contenu qui résulterait en un dommage envers d’autres utilisateurs, comme la propagation de logiciels malveillants tels que des virus informatiques. Sont également interdits la prolifération de messages non sollicités et/ou commerciaux au moyen du site, mais aussi les courriels indésirables, le spamming ou encore les chaînes de lettres.</p><p>[X] se réserve le droit de prendre toutes les mesures nécessaires pour remédier à la situation pour elle et pour ses utilisateurs, à la fois sur le plan judiciaire et extrajudiciaire. L’utilisateur est seul responsable, personnellement et exclusivement, dans le cas où ses actions et son comportement ont effectivement entraîné des dommages au site ou à d’autres utilisateurs. Dans ce cas, l’utilisateur en cause devra s’assurer d’exonérer [X] de toute plainte pour dommage qui s’en suivrait.</p><h2>3. Liens vers d’autres sites internet</h2><p>Le site pourrait contenir des liens ou hyperliens renvoyant vers des sites internet externes ou d’autres formes de portails en ligne. De tels liens ne signifient pas de manière automatique qu’il existe une relation entre nous et le site internet externe ou même que nous sommes implicitement d’accords avec le contenu de ces sites externes.</p><p>[X] n’exerce aucun contrôle sur les sites internet externes. Nous ne sommes donc pas responsables du fonctionnement sûr et correct des hyperliens et de leur destination finale. Dès l’instant où l’utilisateur clique sur l’hyperlien, il quitte notre site. Nous ne pouvons dès lors plus être tenus responsables en cas de dommage ultérieur.</p><p>Il est probable que ces sites internet externes n’offrent pas les mêmes garanties que nous. Ainsi, nous vous suggérons de lire attentivement leurs conditions générales de vente mais aussi leur disclaimer et leur charte vie privée.&nbsp;</p><h2>4. Propriété intellectuelle</h2><p>Le contenu publié sur le site est protégé par les droits de propriété intellectuelle de [X]. Par «&nbsp;contenu&nbsp;», il convient d’entendre les informations, logos, photos, marques, dessins, modèles, slogans, bases de données, etc. accessibles sur le site. Le caractère technique du site en lui-même, à savoir le code informatique, est également protégé par la propriété intellectuelle.</p><p>En visitant notre site, l’utilisateur se voit octroyer un droit limité d’accès, d’utilisation, et d’affichage de notre site et de son contenu. Ce droit est accordé à titre non-exclusif, non-transférable et ne peut être utilisé que moyennant un usage personnel et non commercial. Sauf accord préalable et écrit de [X], les utilisateurs ne sont pas autorisés à modifier, reproduire, traduire, distribuer, vendre, emprunter, louer, communiquer au public, en tout ou en partie, les éléments protégés.</p><h2>5.&nbsp;Protection des données personnelles</h2><p>Les données personnelles fournies par l’utilisateur lors de sa visite et/ou de l’utilisation du site sont collectées et traitées par [X] exclusivement à des fins internes. [X] assure à ses utilisateurs qu’elle attache la plus grande importance à la protection de leur vie privée et de leurs données personnelles, et qu’elle s’engage toujours à communiquer de manière claire et transparente sur ce point.</p><p>[X] s’engage à respecter la législation applicable en la matière, à savoir la Loi du 8 décembre 1992 relative à la protection de la vie privée à l’égard des traitements de données à caractère personnel («&nbsp;Loi vie privée rivée&nbsp;») ainsi que le Règlement européen du 27 avril 2016 relatif à la protection des personnes physiques à l’égard du traitement des données à caractère personnel et à la libre circulation de ces données («&nbsp;Règlement&nbsp;»).</p><p>Les données personnelles de l’utilisateur sont traitées conformément à notre Charte Vie Privée.</p><h2>6.&nbsp;Dispositions générales applicables à nos Conditions Générales</h2><p>[X] se réserve la possibilité de modifier, étendre, supprimer, limiter ou interrompre le site et les services qui y sont associés à tout moment, sans notification préalable, et sans que cela ne donne lieu à une quelconque forme d’indemnisation.</p><p>Nos Conditions Générales (notamment nos conditions générales de vente) sont exécutées et interprétées conformément au droit belge. Tout litige relatif à la validité, l’interprétation ou l’exécution de nos Conditions Générales sera soumis à la compétence exclusive des tribunaux de l’arrondissement judiciaire de [XXX].</p><p>L’illégalité ou la nullité d’une disposition de nos Conditions Générales, en tout ou en partie, n’aura aucun impact sur la validité et l’application des autres dispositions de nos Conditions Générales. Nous disposons, dans un tel cas, du droit de remplacer la clause inapplicable par une autre disposition valable en droit et de portée similaire.</p>\", \"nl\": \"<h1>Disclaimer</h1><p>Het gebruik van onze website moet steeds gebeuren conform de rechten en plichten die duidelijk op de website vermeld staan en de rechten en plichten die bepaald zijn in de Disclaimer, de Verkoopsvoorwaarden en de Privacy Verklaring. Het geheel van deze teksten zijn onze Algemene Voorwaarden.</p><p>Deze Algemene Voorwaarden gelden zowel voor ons, [X], als voor jou, de Gebruiker. Zodra je gebruik maakt van onze website erken en aanvaard je uitdrukkelijk dat onze Algemene Voorwaarden van toepassing zijn en dat volledig verzaakt wordt aan de toepassing van eigen Algemene Voorwaarden.</p><p>Wij kunnen in uitzonderlijke gevallen afwijken van de Algemene Voorwaarden, voor zover deze afwijkingen schriftelijk worden vastgelegd en aanvaard worden door alle partijen. Deze afwijkingen gelden slechts ter vervanging of aanvulling van de clausules waar ze betrekking op hebben en hebben geen effect op de toepassing van overige bepalingen uit de Algemene Voorwaarden.</p><h2>1. Wie zijn wij?</h2><p>De website www.URL is een initiatief van:</p><p>BEDRIJFSNAAM + RECHTSVORM<br />ADRES<br />E-mail:<br />Telefoon:</p><p>Contacteer ons gerust indien u verdere vragen of opmerkingen heeft; wij beloven u een spoedig antwoord!</p><h2>2. Onze website</h2><h3>2.1 Goede werking, veiligheid en toegankelijkheid</h3><p>Je kan ervan op aan, wij bieden een gebruiksvriendelijke website aan die veilig is voor iedere Gebruiker. We nemen dan ook alle redelijke maatregelen die nodig zijn om de goede werking, veiligheid en toegankelijkheid van onze website te garanderen. Toch kunnen we jou geen absolute garanties geven en moet men onze maatregelen beschouwen als een middelenverbintenis.</p><p>Ieder gebruik van de website gebeurt steeds op eigen risico. Dit betekent dat wij geen aansprakelijkheid dragen voor schade die voortvloeit uit storingen, onderbrekingen, schadelijke elementen of defecten aan de website, ongeacht het bestaan van een vreemde oorzaak of overmacht.</p><p>We hebben het recht om de toegang tot onze website te allen tijde te beperken en/of geheel of gedeeltelijk te onderbreken, zonder voorafgaande waarschuwing. We doen dit in principe uitsluitend indien de omstandigheden dit verantwoorden, maar dit is geen absolute voorwaarde.</p><h3>2.2 Inhoud op onze website</h3><p>De inhoud van de website wordt grotendeels door ons bepaald en wij besteden de grootste zorg aan deze inhoud. Dit wil zeggen dat we de nodige maatregelen nemen om onze website zo volledig, nauwkeurig en actueel mogelijk te houden, ook wanneer content wordt aangeleverd door derde partijen. De inhoud op onze website kan steeds gewijzigd, aangevuld of verwijderd worden.</p><p>Toch kunnen we geen garanties geven omtrent de kwaliteit van de informatie op onze website. Het is mogelijk dat informatie niet volledig, voldoende accuraat en/of nuttig is. We zijn bijgevolg niet aansprakelijk voor (directe en indirecte) schade die de Gebruiker lijdt ten gevolge van de informatie op onze website.</p><p>In het geval bepaalde inhoud op onze website een schending van de geldende wetgeving en/of een schending van de rechten van derde partijen betekent en/of eenvoudigweg niet door de beugel kan, vragen wij aan jou om ons dit zo spoedig mogelijk te melden zodat we de gepaste maatregelen kunnen nemen. Zo kunnen we overgaan tot een gedeeltelijke of gehele verwijdering en/of aanpassing van de inhoud.</p><p>Onze website bevat inhoud die gedownload kan worden. Iedere download van onze website gebeurt steeds op eigen risico. Hiervoor zijn wij niet aansprakelijk en schade ten gevolge van een verlies van data of schade aan het computersysteem valt volledig en uitsluitend onder de verantwoordelijkheid van Gebruiker.</p><p>Specifiek voor prijzen en andere informatie over producten op de website geldt een voorbehoud van kennelijke programmeer- en typefouten. De Gebruiker kan op basis van dergelijke fouten geen overeenkomst claimen met [X].</p><h3>2.3 Wat wij van jou als Gebruiker verwachten</h3><p>Ook de Gebruiker draagt een zekere verantwoordelijkheid bij het gebruiken van onze website. De Gebruiker moet zich steeds onthouden van handelingen die een schadelijke impact kunnen hebben op de goede werking en veiligheid van de website. Zo mag de website niet gebruikt worden om ons business model te omzeilen en/of om informatie van andere Gebruikers op grote schaal te verzamelen.</p><p>Het is bijgevolg niet toegelaten om onze website te gebruiken voor de verspreiding van inhoud die schade aan andere Gebruikers van de website kan toebrengen, zoals de verspreiding van schadelijke programmatuur zoals computervirussen, malware, worms, trojans en cancelbots. De verspreiding van ongevraagde en/of commerciële berichten via de website, zoals junk mail, spamming en kettingbrieven, valt hier ook onder.</p><p>Wij behouden ons het recht voor om alle noodzakelijke handelingen te treffen die herstel kunnen opleveren voor ons en voor onze Gebruikers, zowel op gerechtelijk als buitengerechtelijk vlak. De Gebruiker is als enige persoonlijk en integraal verantwoordelijk indien zijn handelingen en gedragingen effectief schade veroorzaken aan de website en de andere Gebruikers. In dat geval moet hij [X] vrijwaren van iedere schadeclaim die volgt.</p><h2>3. Links naar andere websites</h2><p>De inhoud van onze website kan een link, hyperlink of framed link naar vreemde websites of andere vormen van elektronische portalen bevatten. Een link betekent niet automatisch dat er een band tussen ons en de vreemde website bestaat, noch dat wij (impliciet) akkoord gaan met de inhoud van deze websites.</p><p>Wij houden geen controle op deze vreemde websites en zijn niet verantwoordelijk voor de veilige en correcte werking van de link en de uiteindelijke bestemming. Zodra men op de link klikt verlaat men onze website en kan men ons niet meer aansprakelijk stellen voor enige schade.</p><p>Het is mogelijk dat vreemde websites niet dezelfde garanties bieden als wij. Daarom raden wij aan om aandachtig de Algemene Voorwaarden en de Privacy Statement van deze websites door te nemen.</p><h2>4. Intellectuele eigendom</h2><p>Creativiteit verdient bescherming, zo ook onze website en haar inhoud. De bescherming wordt voorzien door intellectuele eigendomsrechten en komt toe aan alle rechthebbende partijen, zijnde [X] en derde partijen. Onder inhoud verstaat men de heel ruime categorie van foto’s, video, audio, tekst, ideeën, notities, tekeningen, artikels, et cetera. Al deze inhoud wordt beschermd door het auteursrecht, softwarerecht, databankrecht, tekeningen- en modellenrecht en andere toepasselijke (intellectuele) eigendomsrechten. Het technische karakter van onze website zelf is beschermd door het auteursrecht, het softwarerecht en databankenrecht.&nbsp; Iedere handelsnaam die wij gebruiken op onze websites wordt eveneens beschermd door het toepasselijke handelsnamenrecht of merkenrecht.</p><p>Iedere Gebruiker krijgt een beperkt recht van toegang, gebruik en weergave van onze websites en haar inhoud. Dit toegekende recht is niet-exclusief, niet-overdraagbaar en kan enkel binnen een persoonlijk, niet-commercieel kader worden gebruikt. Wij vragen onze Gebruikers dan ook om geen gebruik te maken van en/of wijzigingen aan te brengen in de door deze rechten beschermde zaken, zonder de toestemming van de rechthebbende. [X] hecht veel belang aan haar intellectuele eigendomsrechten en heeft hiervoor alle mogelijke maatregelen getroffen om de bescherming te garanderen. Iedere inbreuk op de bestaande intellectuele eigendomsrechten wordt vervolgd.</p><h2>5. Verwerking persoonsgegevens</h2><p>De door jou opgegeven informatie is noodzakelijk voor het verwerken en voltooien van de bestellingen, en het opstellen van de rekeningen en garantiecontracten. Voor elke bestelling is een minimum aan gegevens vereist. Verdere gegevens kunnen gevraagd worden in functie van het personaliseren van de bestelling. Als de minimumgegevens ontbreken wordt de bestelling onvermijdelijk geannuleerd. De persoonsgegevens van de Koper zullen uitsluitend verwerkt worden in overeenstemming met de Privacy Statement te consulteren via onze website.&nbsp;</p><h2>6. Algemene bepalingen omtrent de Algemene Voorwaarden.</h2><p>Wij behouden de vrijheid om onze website en de daarbij horende diensten te allen tijde te wijzigen, uit te breiden, te beperken of stop te zetten. Dit kan zonder voorafgaande kennisgeving van de Gebruiker en geeft evenmin aanleiding tot enige vorm van schadevergoeding.</p><p>Deze Algemene Voorwaarden (inclusief de Verkoopsvoorwaarden) worden exclusief beheerst en geïnterpreteerd in overeenstemming met de Belgische Wetgeving. Alle geschillen die verband houden met of voortvloeien uit aanbiedingen van [X], of overeenkomsten die met haar gesloten zijn, worden voorgelegd aan de bevoegde rechtbank uit het gerechtelijk arrondissement [XXX].</p><p>Indien de werking of geldigheid van één of meerdere van bovenstaande bepalingen van deze Algemene Voorwaarden in het gedrang komen, zal dit geen gevolg hebben op de geldigheid van de overige bepalingen van deze overeenkomst. In dergelijk geval hebben wij het recht om de betrokken bepaling te wijzigen in een geldige bepaling van gelijkaardige strekking.</p>\"}', '{\"en\": 1, \"fr\": 1, \"nl\": 1}', '{\"en\": null, \"fr\": null, \"nl\": null}', '{\"en\": null, \"fr\": null, \"nl\": null}', NULL, NULL, NULL, NULL, '2021-01-20 08:53:43', '2021-01-20 08:53:43');
INSERT INTO `typicms_pages` (`id`, `image_id`, `position`, `parent_id`, `private`, `is_home`, `redirect`, `title`, `slug`, `uri`, `body`, `status`, `meta_keywords`, `meta_description`, `css`, `js`, `module`, `template`, `created_at`, `updated_at`) VALUES
(4, NULL, 4, NULL, 0, 0, 0, '{\"en\": \"Privacy policy\", \"fr\": \"Charte vie privée\", \"nl\": \"Privacyverklaring\"}', '{\"en\": \"privacy-policy\", \"fr\": \"charte-vie-privee\", \"nl\": \"privacyverklaring\"}', '{\"en\": \"privacy-policy\", \"fr\": \"charte-vie-privee\", \"nl\": \"privacyverklaring\"}', '{\"en\": \"<h1>Privacy statement</h1><h2>1. Why this Privacy Statement?</h2><p>Every person (hereafter the “User”) who visits or uses the Website discloses a certain amount of personal data. The personal data is information which allows [X] to identify you as a natural person, regardless of whether we actually do this. You are identifiable as soon as it is possible to create a direct or indirect link between one or more data and you as a natural person.&nbsp;</p><p>We only use and process your personal data in accordance with the GDPR and any replacement legislation, or any similar regulation under any applicable law, and any regulatory requirements or codes of practice governing the use, storage or transmission of personal data. Every reference in this Privacy Statement to the ‘GDPR’ is a reference to the Regulation of 27 April 2016 on the Protection of Natural Persons with regard to the Processing of Personal Data and on the Free Movement of such Data (General Data Protection Regulation).</p><p>Through this Privacy Policy, every User of the Website is informed of the processing activities [X] may carry out with his or her personal data. [X] reserves the right to modify this Privacy Policy at all times. Every substantial change will be clearly communicated towards the User. We advise you to consult this document regularly.</p><h2>2. Who is responsible for the processing of personal data?</h2><h3>2.1. Controller</h3><p>[X] is responsible for the processing and decides alone or in cooperation with others which personal data are being collected as well as the purposes and the technical and organisational means with regard to the processing of those personal data.</p><h3>2.2. Processor(s)</h3><p>[X] is free to rely on data processors. A processor is the natural or legal person who processes your personal data upon request and on behalf of the data controller. The processor is required to ensure the security and confidentiality of the data. The processor shall always act on the instructions of the data controller.</p><p>[X] relies on the following categories of “processors”:</p><ul><li>Companies we have engaged for marketing purposes;</li><li>Companies we have engaged for hosting purposes;</li><li>Companies we have engaged for administrative purposes;</li><li>Companies we have engaged for communication purposes;</li><li>Companies we have engaged for statistical purposes;</li><li>Companies we have engaged for payment purposes.</li></ul><h2>3. On what legal grounds are my data processed?</h2><p>In accordance with the GDPR we process personal data on the following legal grounds:</p><ul><li>On the basis of the execution of the contract agreed upon with you or the execution of pre-contractual steps taken at your request; or</li><li>On the basis of compliance with legal or regulatory provisions with regard to the management of the contractual relationship, invoicing in particular;</li><li>On the basis of our legitimate interest in sending information and newsletters to our customers;</li><li>On the basis of your consent to send promotional offers (direct marketing).</li></ul><h2>4. Which personal data are being processed?</h2><p>[X] commits to only collect and process adequate, relevant and limited to what is necessary for the purposes for which they are processed. The following categories of personal data are processed by [X]:</p><ul><li>Personal identification data (name, first name, address, login details);</li><li>Contact details (telephone number and e-mail address);</li><li>Financial identification data (bank details);</li><li>Electronic identification data (IP address, location, cookies);</li><li>Personal data (gender, age, date and place of birth, nationality).</li><li>…</li></ul><p>This data is collected at the time of your registration on the Website and when you use our services. Other personal data may be collected later, e.g. in the context of our after-sales. These data are necessary for the provision of [X] services. The amount of personal data collected depends on your use of the Website and the functionalities of the Website.</p><p>We also use cookies in order to recognise the User and to offer the User a personalised user experience, to remember technical choices (for example, language choices or a shopping cart), and to detect and correct any errors which might be present on the Website.</p><p>For more information concerning the use of cookies, we kindly refer you to our Cookie Statement.</p><h2>5. For which purposes are my personal data being used?</h2><p>[X] collects your personal data for the sole purpose of offering every User of our a safe, optimised and personal user experience of our Website and the offered services. The collection of personal data becomes more extensive as the User makes more intensive use of our Website and our online services. [X] reserves the right to suspend or cancel certain operations if personal data is missing, incorrect or incomplete.</p><p>The processing of your personal data is essential for the proper functioning of the Website and the provision of associated services. [X] commits to solely process your personal data for the following purposes:</p><ul><li>Customer management: customer administration, order management, deliveries, invoicing, checking creditworthiness, support, complaint monitoring and sending newsletters.</li><li>Dispute management.</li><li>Protection against fraud and infringements.</li><li>Personalized marketing and advertising if you have expressly agreed to it. In that case, you are free to withdraw your consent at any time.</li></ul><p>When visiting the website of [X], some data are being collected for statistical purposes. Such data is necessary to optimise your user experience. These data are: IP-address, probable location of consultation, hour and day of the consultation and the pages which are being consulted. When you visit the Website, you explicitly agree to this collection of data for statistical purposes.</p><p>The User provides the personal data to [X] himself and can therefore exercise some kind of control. When certain data is incomplete or apparently incorrect, the User has the right to postpone some expected actions temporarily or permanently.</p><h2>6. Who receives your personal data?</h2><p>Your personal data are processed for internal use within [X] only. Your personal data will not be sold, passed on or communicated to any third parties, except in case you have given us your explicit prior consent.</p><h2>7. How long do we store your personal data?</h2><p>Your data is stored as long as necessary to achieve the ends pursued. They will be erased from our database as soon as they are no longer necessary for the ends pursued or if you validly exercise your right to erasure.</p><h2>8. What are my rights?</h2><h3>8.1. Guarantee of a legitimate and secure process of your personal data</h3><p>Your personal data are always processed for the legitimate purposes explained in point 5. They are collected and processed in an appropriate, relevant and non-excessive manner, and are not kept longer than necessary to achieve the intended purposes.</p><h3>8.2. Right to access</h3><p>If you can prove your identity, you have the right to obtain information about the processing of your data. Thus, you have the right to know the purposes of the processing, the categories of data concerned, the categories of recipients to whom the data are transmitted, the criteria used to determine the data retention period, and the rights that you can exercise on your data.</p><h3>8.3. Right to rectification of your personal data</h3><p>Inaccurate or incomplete personal data may be corrected. It is primarily the responsibility of the User to make the necessary changes in his “user area” himself, but you can also request us in writing.</p><h3>8.4. Right to erasure (or “right to be forgotten”)</h3><p>You also have the right to obtain the erasure of your personal data under the following assumptions:</p><ul><li>Your personal data are no longer necessary for the intended purposes;</li><li>You withdraw your consent to the processing and there is no other legal ground for processing;</li><li>You have validly exercised your right of opposition;</li><li>Your data has been illegally processed;</li><li>Your data must be deleted to comply with a legal obligation.</li></ul><p>The deletion of data is mainly related to visibility; it is possible that the deleted data are still temporarily stored.</p><h3>8.5. Right to limitation of processing</h3><p>In certain cases, you have the right to request the limitation of the processing of your personal data, especially in case of dispute as to the accuracy of the data, if the data are necessary in the context of legal proceedings or the time required to [X] to verify that you can validly exercise your right to erasure.</p><h3>8.6. Right to object</h3><p>You have the right to object at any time to the processing of your personal data for direct marketing purposes. [X] will stop processing your personal data unless it can demonstrate that there are compelling legitimate reasons for the processing which prevail over your right to object.</p><h3>8.7. Right to data portability</h3><p>You have the right to obtain any personal data which you have provided us in a structured, commonly used and machine readable format. At your request, this data may be transferred to another provider unless it is technically impossible.</p><h3>8.8. Right to withdraw your consent</h3><p>You may withdraw your consent to the processing of your personal data at any time, for example for direct marketing purposes.</p><h2>9. How to exercise my rights?</h2><p>If you wish to exercise your rights, you must send a written request and proof of identity by registered mail to [X] or by email to [EMAIL]. We will respond as soon as possible, and no later than one (1) month after receipt of the request.</p><h2>10. Possibility to lodge a complaint</h2><p>If you are not satisfied with the processing of your personal data by [X], you have the right to lodge a complaint with the competent Data Protection Authority (for Belgium: <a href=\\\"https://www.privacycommission.be/)\\\">https://www.privacycommission.be/</a>).</p>\", \"fr\": \"<h1>Charte vie privée</h1><h2>1. Pourquoi cette charte vie privée&nbsp;?</h2><p>[X] accorde beaucoup d’importance à la protection de votre vie privée et de vos données personnelles. Nous collectons et traitons vos données personnelles conformément aux dispositions légales applicables en la matière, à savoir la Loi du 8 décembre 1992 relative à la protection de la vie privée à l’égard des traitements de données à caractère personnel («&nbsp;Loi vie privée&nbsp;») et le Règlement européen du 27 avril 2016 relatif à la protection des personnes physiques à l’égard du traitement des données à caractère personnel et à la libre circulation de ces données («&nbsp;Règlement&nbsp;»).</p><p>Nous souhaitons vous informer des éventuelles opérations de traitement de vos données personnelles et de vos droits à cet égard. En utilisant notre [site/plateforme/application], vous acceptez expressément la collecte et le traitement de vos données personnelles par [X] de la manière décrite dans ce document.</p><p>Nous nous réservons le droit d’apporter à tout moment des modifications à notre Charte vie privée. Toute modification substantielle sera toujours communiquée clairement sur notre [site/plateforme/application]. Nous vous conseillons néanmoins de consulter régulièrement ce document.</p><h2>2. Qui traite vos données personnelles&nbsp;?</h2><p>[X] est responsable [du site/de la plateforme/l’application].</p><p><strong>Informations de contact&nbsp;:</strong></p><p>NOM + FORME JURIDIQUE<br />RUE ET NUMERO<br />CODE POSTAL ET COMMUNE<br />Belgique</p><p><strong>Numéro d’entreprise (TVA-BE)&nbsp;:</strong></p><p><strong>E-mail&nbsp;:</strong></p><p><strong>Téléphone&nbsp;:</strong></p><h2>3. Quelles données personnelles sont collectées?</h2><p>Le traitement de vos données personnelles est limité au strict nécessaire pour atteindre les finalités poursuivies par [X].&nbsp; Ci-dessous, sont énumérées les catégories de données concernées par le traitement.</p><ul><li>Données d’identification</li><li>Données financières</li><li>Données de localicalisation</li><li>Données relatives à la connexion (adresse IP, etc.)</li><li>Caractéristiques personnelles</li><li>Données physiques</li><li>Habitudes de vie</li><li>Composition du ménage et de la famille</li><li>Loisirs et intérêts</li><li>Affiliations et appartenances</li><li>Données judiciaires</li><li>Habitudes de consommation</li><li>Données relatives aux études et à la formation</li><li>Données relatives à l’emploi et à la fonction</li><li>Numéro de registre national et numéro d’identification de la sécurité sociale</li><li>Données raciales ou ethniques</li><li>Données sur la vie sexuelle ou l’orientation sexuelle</li><li>Opinions politiques</li><li>Convictions religieuses ou philosophiques</li><li>Photos / Prises de vue</li><li>Enregistrements / Prises de son</li></ul><h2>4. Quelles sont les finalités poursuivies?</h2><p>[X] recueille vos données personnelles dans le seul objectif de vous fournir une expérience d’utilisation optimale, personnalisée et en toute sécurité [du site/de la plateforme/l’application]. La collecte de vos données personnelles peut s’intensifier de par une utilisation plus intensive de notre [site/plateforme/application].</p><p>Le traitement de vos données personnelles est donc essentiel au bon fonctionnement [du site/de la plateforme/l’application] et à la fourniture de nos services. [X] s’engage à traiter vos données personnelles exclusivement aux fins suivantes&nbsp;:</p><ul><li>Vous permettre d’avoir accès à votre «&nbsp;compte utilisateur&nbsp;»</li><li>Assurer le traitement des commandes et la livraison des produits&nbsp;</li><li>Assurer le service après-vente&nbsp;</li><li>Gérer la relation contractuelle&nbsp;</li><li>Permettre la facturation et la gestion des comptes&nbsp;</li><li>Offrir à l’Utilisateur un service général mais aussi personnalisé, incluant l’envoi d’information utile, de newsletters, la fourniture de soutien et le suivi des plaintes.</li><li>Améliorer et personnaliser nos services et nos produits</li><li>Détecter les fraudes, les erreurs et les comportements criminels.</li><li>Envoyer des offres promotionnelles si vous y avez expressément consenti (marketing direct). Dans ce cas, vous restez libre de retirer votre consentement à tout moment</li></ul><p>En visitant notre [site/plateforme/application], certaines données sont collectées à des fins statistiques. Ces données nous permettent d’optimiser votre expérience d’utilisation. Il s’agit de votre adresse IP, de la zone géographique de consultation, du jour et de l’heure de consultation, et des pages consultées. En visitant notre [site/plateforme/application], vous acceptez expressément la collecte de ces données à des fins statistiques.</p><p>Vous exercez un contrôle sur les données que vous nous communiquez. Lorsque des données sont incomplètes ou erronées, [X] se réserve le droit d’interrompre ou de suspendre, de manière temporaire ou permanente, certaines opérations.</p><p>Vos données personnelles sont destinées à être utilisées exclusivement à des fins internes. Vos données personnelles ne seront donc pas vendues, données ou transmises à des tiers, sauf consentement préalable de votre part. [X] a pris toutes les mesures techniques et organisationnelles possibles pour éviter une violation des données.</p><h2>5. Nous utilisons aussi des cookies&nbsp;!</h2><p>Lors de votre visite sur notre [site/plateforme/application], des cookies peuvent être placés sur le disque dur de votre ordinateur. Nous utilisons des cookies pour offrir une expérience d’utilisation optimale à nos visiteurs réguliers.</p><p>Pour plus d’informations sur l’utilisation que nous faisons des cookies, nous vous invitons à consulter notre Politique des cookies.</p><p>Si vous visitez notre [site/plateforme/application], nous vous conseillons d’activer vos cookies. Toutefois, vous restez libre de les désactiver via les paramètres de votre navigateur si vous souhaitez. Pour plus de détails, nous vous renvoyons vers notre Politique des cookies.</p><h2>6. Quels sont mes droits&nbsp;?</h2><h3>6.1. Garantie d’un traitement loyal et licite</h3><p>Vos données personnelles sont toujours traitées conformément aux fins légitimes explicitées au point 4. Elles sont collectées et traitées de manière adéquate, pertinente et non-excessive, et ne sont pas conservées plus longtemps que nécessaire pour atteindre les finalités poursuivies.</p><p>Toutes les mesures techniques et sécuritaires ont été prises pour limiter au maximum les risques d’accès ou de traitement illégal ou non-autorisé de vos données personnelles. En cas d’intrusion dans ses systèmes informatiques, [X] prendra immédiatement toutes les mesures nécessaires pour réduire les dommages à leur minimum.</p><h3>6.2. Droit d’accès</h3><p>Si vous êtes en mesure de prouver votre identité, vous avez le droit d’obtenir des informations sur le traitement de vos données. Ainsi vous avez le droit de connaître les finalités du traitement, les catégories de données concernées, les catégories de destinataires auxquels les données sont transmises, les critères utilisés pour déterminer la durée de conservation des données, et les droits que vous pouvez exercer sur vos données.</p><h3>6.3. Droit de rectification</h3><p>Les données personnelles inexactes ou incomplètes peuvent être corrigées. Il incombe en premier lieu à l’Utilisateur d’effectuer lui-même les changements nécessaires dans son «&nbsp;compte utilisateur&nbsp;» mais vous pouvez également nous en faire la demande écrite.</p><h3>6.4. Droit à l’effacement (ou «&nbsp;droit à l’oubli&nbsp;»)</h3><p>Vous avez en outre le droit d’obtenir l’effacement de vos données personnelles dans les hypothèses suivantes&nbsp;:</p><ul><li>Vos données personnelles ne sont plus nécessaires au regard des finalités&nbsp;;</li><li>Vous retirez votre consentement au traitement et il n’existe pas d’autre fondement légal au traitement&nbsp;;</li><li>Vous avez valablement exercé votre droit d’opposition&nbsp;;</li><li>Vos données ont fait l’objet d’un traitement illégal&nbsp;;</li><li>Vos données doivent être supprimées pour respecter une obligation légale.</li></ul><p>[X] décide de son propre chef de la présence des critères repris ci-dessus.</p><h3>6.5. Droit à la limitation du traitement</h3><p>Dans certaines hypothèses, vous avez le droit de demander la limitation du traitement de vos données personnelles, notamment en cas de contestation quant à l’exactitude des données, si vos données ont été traitées illégalement, si les données sont nécessaires dans le cadre d’une procédure judiciaire ou le temps nécessaire à [X] pour vérifier que vous pouvez valablement exercer votre droit à l’effacement.</p><h3>6.6. Droit d’opposition</h3><p>Vous avez en outre le droit de vous opposer à tout moment au traitement de vos données personnelles. [X] cessera le traitement de vos données personnelles, à moins qu’elle ne parvienne à démontrer qu’il existe des motifs légitimes impérieux en faveur du traitement qui prévalent sur votre droit d’opposition.</p><h3>6.7. Droit à la portabilité des données</h3><p>Vous avez le droit d’obtenir toutes les données personnelles que vous nous avez fournies dans un format structuré, couramment utilisé et lisible par machine. À votre demande, ces données peuvent être transférées à un autre prestataire, à moins que cela soit techniquement impossible.</p><h3>6.8. Droit du retrait de votre consentement</h3><p>Vous pouvez retirer à tout moment votre consentement au traitement de vos données personnelles. Le retrait de votre consentement n’entache pas la validité des opérations de traitement antérieures au retrait.</p><h2>7. Comment exercer mes droits&nbsp;?</h2><p>Pour exercer vos droits, vous devez nous envoyer une demande par courrier recommandé à [X] ou par mail à [EMAIL]. Nous y répondrons dans les meilleurs délais, et au plus tard un (1) mois après réception de la demande.</p><h2>8. Possibilité d’introduire une plainte</h2><p>Si vous n’êtes pas satisfait du traitement de vos données personnelles par [X], vous avez le droit d’introduire une plainte auprès de la Commission pour la Protection de la Vie Privée, qui devient l’Autorité de Protection des Données à partir du 25 mai 2018 (<a href=\\\"https://www.autoriteprotectiondonnees.be/\\\">www.autoriteprotectiondonnees.be</a>).</p>\", \"nl\": \"<h1>Privacyverklaring</h1><h2>1. Waarom deze privacyverklaring?</h2><p>[X] hecht grote waarde aan de bescherming van uw privacy en persoonsgegevens. Wij gebruiken uw persoonsgegevens uitsluitend in overeenstemming met de Privacywet en andere relevante vigerende wettelijke voorschriften. Iedere verwijzing in deze Privacyverklaring naar de Privacywet betekent een verwijzing naar de Wet van 8 december 1992 tot bescherming van de persoonlijke levenssfeer ten opzichte van de verwerking van persoonsgegevens. Iedere verwijzing naar de Verordening is een verwijzing naar de Verordening van 27 april 2016 betreffende de bescherming van natuurlijke personen in verband met de verwerking van persoonsgegevens en betreffende het vrije verkeer van die gegevens.</p><p>Met deze Privacyverklaring wil [X] u wijzen op eventuele verwerkingshandelingen ten aanzien van deze gegevens en op uw rechten. Door gebruik te maken van [onze website/ons platform/onze applicatie] verleent u expliciet uw toestemming met mogelijke verwerkingshandelingen door [X].</p><p>Het is mogelijk dat deze Privacyverklaring in de toekomst onderhevig is aan aanpassingen en wijzigingen. Het is aan u om op regelmatige basis dit document te raadplegen. Iedere substantiële wijziging zal steeds duidelijk gecommuniceerd worden op [de website/het platform/de applicatie] van [X].</p><h2>2.Wie verwerkt de persoonsgegevens?</h2><p>[X] is verantwoordelijk voor de [de website/het platform/de applicatie].</p><p>    LID ONDERNEMINGSVORM<br />    STRAAT HUISNUMMER<br />    POSTCODE GEMEENTE<br />    België</p><p><strong>Btw-nummer:</strong></p><p><strong>E-mail:</strong></p><p><strong>Telefoon:</strong></p><h2>3. Welke persoonsgegevens worden verwerkt?</h2><p>[X] verbindt zich ertoe enkel de gegevens te verwerken die ter zake dienend zijn en noodzakelijk zijn voor de doeleinden waarvoor zij verzameld werden. Volgende categorieën van persoonsgegevens kunnen verwerkt worden door [X]:</p><ul>    <li>Identificatiegegevens</li>    <li>Financiële bijzonderheden</li>    <li>Persoonlijke kenmerken</li>    <li>Fysieke gegevens</li>    <li>Leefgewoonten</li>    <li>Psychische gegevens</li>    <li>Samenstelling van het gezin</li>    <li>Vrijetijdsbesteding en interessen</li>    <li>Lidmaatschappen</li>    <li>Gerechtelijke gegevens</li>    <li>Consumptiegewoonten</li>    <li>Woningkenmerken</li>    <li>Gegevens omtrent opleiding en vorming</li>    <li>Gegevens omtrent beroep en betrekking</li>    <li>Rijksregisternummer en identificatienummer van de sociale zekerheid</li>    <li>Raciale of etnische gegevens</li>    <li>Gegevens over het seksuele leven</li>    <li>Politieke opvattingen</li>    <li>Filosofische of religieuze overtuigingen</li>    <li>Beeldopnamen</li>    <li>Geluidsopnamen</li></ul><h2>4. Voor welke doeleinden worden mijn persoonsgegevens gebruikt?</h2><p>[X] verzamelt persoonsgegevens om u een veilige, optimale en persoonlijke gebruikerservaring te bieden. De verzameling van persoonsgegevens wordt uitgebreider naarmate u intensiever gebruik maakt van [de website/het platform/de applicatie] en onze online dienstverlening.</p><p>Gegevensverwerking is essentieel voor de werking van [de website/het platform/de applicatie] en de daarbij horende diensten. De verwerking gebeurt uitsluitend voor volgende welbepaalde doeleinden:</p><ul>    <li>U toegang verschaffen tot uw gebruikersprofiel.</li>    <li>Het aanbieden en verbeteren van een algemene en gepersonaliseerde dienstverlening; inclusief facturatiedoeleinden, aanbod van informatie, nieuwsbrieven en aanbiedingen die nuttig en/of noodzakelijk zijn voor u, de verkrijging en verwerking van gebruikersbeoordelingen en het verlenen van ondersteuning.</li>    <li>Het aanbieden en verbeteren van de aangeleverde producten; persoonsgerichte en specifieke producten aan de hand van geleverde informatie en gegevens.</li>    <li>De detectie van en bescherming tegen fraude, fouten en/of criminele gedragingen.</li>    <li>Marketing doeleinden</li></ul><p>Bij een bezoek aan [de website/het platform/de applicatie] van [X] worden er enkele gegevens ingezameld voor statistische doeleinden. Dergelijke gegevens zijn noodzakelijk om het gebruik van [onze website/ons platform/onze applicatie] te optimaliseren. Deze gegevens zijn: IP-adres, vermoedelijke plaats van consultatie, uur en dag van consultatie, welke pagina’s er werden bezocht. Wanneer u [de website/het platform/de applicatie] van [X] bezoekt verklaart u zich akkoord met deze gegevensinzameling bestemd voor statische doeleinden zoals hierboven omschreven.</p><p>De Gebruiker verschaft steeds zelf de persoonsgegevens aan [X] en kan op die manier een zekere controle uitoefenen. Indien bepaalde gegevens onvolledig of ogenschijnlijk incorrect zijn, behoudt LID zich het recht voor bepaalde verwachte handelingen tijdelijk of permanent uit te stellen.</p><p>    De persoonsgegevens worden enkel verwerkt voor intern gebruik binnen [X].<br />    We kunnen u dan ook geruststellen dat persoonsgegevens niet verkocht, doorgegeven of meegedeeld worden aan derde partijen die aan ons verbonden zijn. [X] heeft alle mogelijke juridische en technische voorzorgen genomen om ongeoorloofde toegang en gebruik te vermijden.</p><h2>5. Wij gebruiken ook cookies!</h2><p>Tijdens een bezoek aan [onze website/ons platform/onze applicatie] kunnen ‘cookies’ op uw harde schijf geplaatst worden om [de website/het platform/de applicatie] beter af te stemmen op de behoeften van de terugkerende bezoeker. Niet-functionele cookies helpen ons om uw bezoek aan [de website/het platform/de applicatie] te optimaliseren en om technische keuzes te herinneren.</p><p>Voor een verder begrip van de wijze waarop wij cookies gebruiken om uw persoonsgegevens te verzamelen en te verwerken, verwijzen wij u graag door naar onze Cookieverklaring.</p><p>Als u [de website/het platform/de applicatie] van [X] wil consulteren, is het aan te raden dat u cookies ingeschakeld hebt. Hoe u cookies daarentegen kan uitschakelen, staat eveneens te lezen in onze Cookieverklaring.</p><h2>6. Wat zijn mijn rechten?</h2><h3>6.1. Garantie van een rechtmatige en veilige verwerking van de persoonsgegevens</h3><p>[X] verwerkt uw persoonsgegevens steeds eerlijk en rechtmatig. Dit houdt volgende garanties in:</p><ul>    <li>Persoonsgegevens worden enkel conform de omschreven en gerechtvaardigde doeleinden van deze Privacyverklaring verwerkt.</li>    <li>Persoonsgegevens worden enkel verwerkt voor zover dit toereikend, ter zake dienend en niet overmatig is.</li>    <li>Persoonsgegevens worden maar bewaard zolang dit noodzakelijk is voor het verwezelijken van de omschreven en gerechtvaardigde doeleinden in deze Privacyverklaring.</li></ul><p>De nodige technische en beveiligingsmaatregelen werden genomen om de risico’s op onrechtmatige toegang tot of verwerking van de persoonsgegevens tot een minimum te reduceren. Bij inbraak in haar informaticasystemen zal [X] onmiddellijk alle mogelijke maatregelen nemen om de schade tot een minimum te beperken.</p><h3>6.2. Recht op inzage/rectificatie/wissen van uw persoonsgegevens</h3><p>Bij bewijs van uw identiteit als Gebruiker, beschikt u over een recht om van [X] uitsluitsel te krijgen over het al dan niet verwerken van uw persoonsgegevens. Wanneer [X] uw gegevens verwerkt, heeft u bovendien het recht om inzage te verkrijgen in de verzamelde persoonsgegevens. Indien u wenst uw recht op inzage te gebruiken, zal [X] hieraan gevolg geven binnen één (1) maand na het ontvangen van de aanvraag. De aanvraag gebeurt via aangetekende zending of via het versturen van een e-mail naar [X]</p><p>Onnauwkeurige of onvolledige persoonsgegevens kunnen steeds verbeterd worden. Het is aan de Gebruiker om in de eerste plaats zelf onnauwkeurigheden en onvolledigheden aan te passen. U kan uw recht op verbetering uitoefenen door een aanvullende verklaring te verstrekken aan [X]. [X] zal hieraan gevolg geven binnen één (1) maand na het ontvangen van de aanvullende verklaring.</p><p>U heeft bovendien het recht om zonder onredelijke vertraging uw persoonsgegevens door ons te laten wissen. U kan slechts beroep doen op dit recht om vergeten te worden in de hiernavolgende gevallen:</p><ul>    <li>Wanneer de persoonsgegevens niet langer nodig zijn voor de doeleinden waarvoor zij oorspronkelijk werden verzameld;</li>    <li>Wanneer de persoonsgegevens verzameld werden op basis van verkregen toestemming en geen andere rechtsgrond bestaat voor de verwerking;</li>    <li>Wanneer bezwaar wordt gemaakt tegen de verwerking en geen prevalerende dwingende gerechtvaardigde gronden voor de verwerking bestaan;</li>    <li>Wanneer de persoonsgegevens onrechtmatig werden verwerkt;</li>    <li>Wanneer de persoonsgegevens gewist moeten worden overeenkomstig een wettelijke verplichting.</li></ul><p>[X] beoordeelt de aanwezigheid van een van de voornoemde gevallen.</p><h3>6.3. Recht op beperking van/bezwaar tegen de verwerking van uw persoonsgegevens</h3><p>Gebruiker heeft het recht om een beperking van de verwerking van uw persoonsgegevens te verkrijgen:</p><ul>    <li>Gedurende de periode die [X] nodig heeft om de juistheid van de persoonsgegevens te controleren, in geval van betwisting;</li>    <li>Wanneer de gegevensverwerking onrechtmatig is en Gebruiker verzoekt tot een beperking van de verwerking in plaats van het wissen van de persoonsgegevens;</li>    <li>Wanneer [X] de persoonsgegevens van de Gebruiker niet meer nodig heeft voor de verwerkingsdoeleinden en Gebruiker de persoonsgegevens nodig heeft inzake een rechtsvordering;</li>    <li>Gedurende de periode die [X] nodig heeft om de aanwezigheid van de gronden voor het wissen van persoonsgegevens te beoordelen.</li></ul><p>Gebruiker heeft bovendien te allen tijde het recht om bezwaar te maken tegen de verwerking van zijn persoonsgegevens. [X] staakt hierna de verwerking van uw persoonsgegevens, tenzij [X] dwingende gerechtvaardigde gronden voor de verwerking van uw persoonsgegevens kan aanvoeren die zwaarder wegen dan het recht van de Gebruiker op bezwaar.</p><p>Indien Gebruiker wenst om deze rechten uit te oefenen, zal [X] hieraan gevolg geven binnen één&nbsp; (1) maand na het ontvangen van de aanvraag. De aanvraag gebeurt via aangetekende zending of via een e-mail naar&nbsp;[EMAIL].</p><h3>6.4. Recht op gegevensoverdraagbaarheid</h3><p>Gebruiker heeft het recht om de aan [X] verstrekte persoonsgegevens in een gestructureerde, gangbare en machine leesbare vorm te verkrijgen. Daarnaast heeft Gebruiker het recht om deze persoonsgegevens over te dragen aan een andere verwerkingsverantwoordelijke wanneer de verwerking van de persoonsgegevens uitsluitend rust op de verkregen toestemming van de Gebruiker.</p><p>Indien Gebruiker wenst om dit recht uit te oefenen, zal [X] hieraan gevolg geven binnen één (1) maand na het ontvangen van de aanvraag. De aanvraag gebeurt via aangetekende zending of via een e-mail naar [EMAIL].</p><h3>6.5. Recht op het intrekken van mijn toestemming/recht om klacht in te dienen</h3><p>Gebruiker heeft te allen tijde het recht om zijn toestemming in te trekken. Het intrekken van de toestemming laat de rechtmatigheid van de verwerking op basis van de toestemming vóór de intrekking daarvan, onverlet. Daarnaast heeft Gebruiker het recht om klacht in te dienen betreffende de verwerking van zijn persoonsgegevens door [X] bij de Belgische Commissie voor de Bescherming van de Persoonlijke Levenssfeer.</p><p>Indien Gebruiker wenst dit recht uit te oefenen, zal [X] hieraan gevolg geven binnen één (1) maand na het ontvangen van de aanvraag. De aanvraag gebeurt via aangetekende zending of via e-mail naar [EMAIL].</p><h3>6.6. Recht op bezwaar</h3><p>Gebruiker heeft bovendien te allen tijde het recht om bezwaar te maken tegen de verwerking van zijn persoonsgegevens. [X] staakt hierna de verwerking van uw 5 / 5 persoonsgegevens, tenzij de vzw dwingende gerechtvaardigde gronden voor de verwerking van uw persoonsgegevens kan aanvoeren die zwaarder wegen dan het recht van de Gebruiker op bezwaar.</p><h3>6.7. Recht op gegevensoverdraagbaarheid</h3><p>Gebruiker heeft het recht om de aan de [X] verstrekte persoonsgegevens in een gestructureerde, gangbare en machine leesbare vorm te verkrijgen. Daarnaast heeft Gebruiker het recht om deze persoonsgegevens over te dragen aan een andere verwerkingsverantwoordelijke wanneer de verwerking van de persoonsgegevens uitsluitend rust op de verkregen toestemming van de Gebruiker.</p><h3>6.8. Recht op het intrekken van mijn toestemming</h3><p>Gebruiker heeft te allen tijde het recht om zijn toestemming in te trekken. Het intrekken van de toestemming laat de rechtmatigheid van de verwerking op basis van de toestemming vóór de intrekking daarvan, onverlet.</p><h2>7. Hoe kan ik mijn rechten uitoefenen?</h2><p>Indien Gebruiker wenst om deze rechten uit te oefenen, zal de [X] hieraan gevolg geven binnen één (1) maand na het ontvangen van de aanvraag. De aanvraag gebeurt via aangetekende zending aan [X], of via een e-mail naar [EMAIL].</p><h2>8. Recht om klacht in te dienen</h2><p>Daarnaast heeft Gebruiker het recht om klacht in te dienen betreffende de verwerking van zijn persoonsgegevens door de [X] bij de Belgische Commissie voor de Bescherming van de Persoonlijke Levenssfeer (<a href=\\\"https://www.gegevensbeschermingsautoriteit.be\\\">www.gegevensbeschermingsautoriteit.be</a>).</p>\"}', '{\"en\": 1, \"fr\": 1, \"nl\": 1}', '{\"en\": null, \"fr\": null, \"nl\": null}', '{\"en\": null, \"fr\": null, \"nl\": null}', NULL, NULL, NULL, NULL, '2021-01-20 08:53:43', '2021-01-20 08:53:43');
INSERT INTO `typicms_pages` (`id`, `image_id`, `position`, `parent_id`, `private`, `is_home`, `redirect`, `title`, `slug`, `uri`, `body`, `status`, `meta_keywords`, `meta_description`, `css`, `js`, `module`, `template`, `created_at`, `updated_at`) VALUES
(5, NULL, 5, NULL, 0, 0, 0, '{\"en\": \"Cookie policy\", \"fr\": \"Politique des cookies\", \"nl\": \"Cookieverklaring\"}', '{\"en\": \"cookie-policy\", \"fr\": \"politique-des-cookies\", \"nl\": \"cookieverklaring\"}', '{\"en\": \"cookie-policy\", \"fr\": \"politique-des-cookies\", \"nl\": \"cookieverklaring\"}', '{\"en\": \"<h1>Cookie policy</h1><h2>1. Cookies</h2><p>A cookie is a small text file that is placed on the hard disk of your computer or mobile device when you visit a website. The cookie is placed on your device by the website itself (“first party cookies”) or by partners of the website (“third party cookies”). The cookie identifies your device by a unique identification number when you return to the website and collects information about your browsing behaviour.</p><p>There are different types of cookies. We distinguish the following cookies according to their purposes: there are essential or strictly necessary cookies and non-essential cookies (functional, analytical and targeting cookies)</p><p>The Belgian Act concerning the Electronic Communication of 13 June 2005 contains some provisions about cookies and the use thereof on websites. The Belgian implementation is deduced of the European e-Privacy Directive, which implies that the cookie usage and the cookie legislation is regulated differently in every European country. [X] is a Belgium-based webshop and therefore follows the Belgian and European legislation on cookies.</p><h2>2. Goals and utilities of cookies</h2><p>By using the website, the visitor may agree to the use of cookies. Cookies help [X] to optimize your visit to the website and to provide you with an optimal user experience. However, you are free to delete or restrict cookies at any time by changing your browser settings (see “Management of cookies”).</p><p>Disabling cookies can have an impact on the functioning of the website. Some of the site’s features may be restricted or inaccessible. If you decide to disable cookies, we cannot guarantee you a smooth and optimal visit to our website.</p><h2>3. Types of cookies used by [X]</h2><p>We distinguish the following types of cookies, according to their purposes:</p><h3>Essential / Strictly necessary cookies:</h3><p>These cookies are necessary for the website to function and cannot be disabled in our systems. They are usually only set up in response to your actions, such as setting up your privacy preferences, logging in or filling in forms. They are necessary for a good communication and they facilitate navigating (for example, returning to a previous page, etc.).</p><h3>Non-essential cookies:</h3><p>These cookies are not necessary for the website to function, but they do help us to offer an improved and personalized website.</p><ul><li><strong>Functional cookies:</strong><br />These cookies enable the website to offer improved functionality and personalization. They can be set up by us or by external providers whose services we have added to our pages.</li><li><strong>Analytical cookies:</strong><br />With these cookies, we can track visits and traffic so that we can measure and improve the performance of our site. They help us to determine which pages are the most and the least popular and how visitors move through the site.</li><li><strong>Targeting / advertising cookies:</strong><br />These cookies can be set by our advertising partners via our site. They can be used by those companies to create a profile of your interests and show you relevant ads on other sites.</li></ul><p>We use two types of cookies, namely our own functional cookies and cookies of carefully selected partners with whom we cooperate and who advertise our services on their website.</p><h3>First party cookies:</h3><p>Domain name: [URL]</p><div class=\\\"table-responsive\\\"><table><tbody><tr><td>Name of the cookie</td><td>Type of cookie</td><td>Retention period</td></tr><tr><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr></tbody></table></div><h3>Third party cookies:</h3><p>Domain name: [URL]</p><div class=\\\"table-responsive\\\"><table><tbody><tr><td>Name of the cookie</td><td>Type of cookie</td><td>Retention period</td></tr><tr><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr></tbody></table></div><p>Domain name: [URL]&nbsp;</p><div class=\\\"table-responsive\\\"><table><tbody><tr><td>Name of the cookie</td><td>Type of cookie</td><td>Retention period</td></tr><tr><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr></tbody></table></div><p>Carefully read our <a href=\\\"{!! page:4 !!}\\\">Privacy policy</a> for more information concerning the processing of personal data by [X].</p><h2>4. Management of cookies</h2><p>Make sure that cookies are enabled in your web browser. If you want to consult the website of BEGUMMY, it is recommended you enable cookies. However, you are free to disable cookies in your browser settings if you wish to do so.</p><p>To enable or disable cookies, you must change your browser settings (via the “preferences” or “options” tab). The following links will give you more information on how to manage your cookies. You can also consult the “help” tab of your browser.</p><ul><li><a href=\\\"https://support.microsoft.com/en-gb/help/17442/windows-internet-explorer-delete-manage-cookies\\\">How to delete and manage cookies in Internet Explorer</a></li><li><a href=\\\"https://support.mozilla.org/en-US/kb/enable-and-disable-cookies-website-preferences\\\">How to delete and manage cookies in Mozilla Firefox</a></li><li><a href=\\\"https://support.google.com/chrome/answer/95647?co=GENIE.Platform%3DDesktop&amp;hl=en-GB\\\">How to delete and manage cookies in Chrome</a></li><li><a href=\\\"https://support.apple.com/en-gb/guide/safari/manage-cookies-and-website-data-sfri11471/mac\\\">How to delete and manage cookies in Safari </a></li></ul><h2>5. Rights of the visitors</h2><p>Since cookies may constitute a processing of personal data, you as a data subject have the right to the lawful and secure processing of personal data. More information about the way in which we collect and process your personal data, as well as about your rights, can be found in our <a href=\\\"{!! page:4 !!}\\\">Privacy policy</a>.</p>\", \"fr\": \"<h1>Politique des cookies</h1><h2>1. Cookies</h2><p>Les cookies sont de petits fichiers de données ou de texte placés sur votre ordinateur local par des sites internet ou des applications. De tels cookies peuvent poursuivre différentes finalités. On distingue ainsi les cookies fonctionnels (par exemple, lorsque vous faites un choix de langue ou lorsque vous ajoutez des achats à votre «&nbsp;caddy&nbsp;»), les cookies de session (temporaires)&nbsp;et les cookies de tracking (qui analysent et enregistrent le comportement que vous adoptez sur le site internet en question afin de vous offrir une expérience d’utilisation optimale).</p><p>La loi belge du 13 juin 2005 relative aux communications électroniques contient quelques dispositions relatives aux cookies et à leur utilisation sur les sites internet. L’application de la loi belge découle de la directive européenne e-Privacy, ce qui implique que l’utilisation des cookies et leur réglementation au niveau national diffèrent selon les pays européens.</p><p>[X] est une entreprise active sur le marché belge, elle suit par conséquent la législation belge en la matière.</p><h2>2. Quelle est l’utilité des cookies&nbsp;?</h2><p>[X] souhaite vous informer le plus précisément possible des règles entourant l’utilisation des cookies et des types de cookies qu’elle utilise sur son site. En utilisant notre site, vous marquez votre accord avec l’utilisation de cookies. Les cookies aident [X] à optimiser votre visite de son site internet, à se souvenir de vos choix techniques (comme un choix de langue, une newsletter, etc.), et à vous proposer des offres et des services toujours plus adaptés à vos besoins.</p><p>Pour pouvoir utiliser le site internet de [X], il est recommandé d’activer les cookies. Si les cookies sont désactivés, il est possible que nous ne soyons pas en mesure de vous garantir une visite de notre site qui soit dénuée de tout problème technique. Cependant, vous restez tout à fait libre de désactiver les cookies si vous le souhaitez.</p><p>Nous utilisons des cookies pour améliorer votre visite et votre utilisation de notre site internet. Les cookies que nous utilisons sont sûrs. Les informations que nous collectons à l’aide des cookies nous aident à identifier les éventuelles erreurs qui se trouvent sur notre site internet et à vous proposer des services spécifiques et personnalisés dont nous pensons qu’ils peuvent vous intéresser.</p><h2>3. Quels types de cookies utilise [X]?</h2><p>Nous distinguons les types de cookies suivants, en fonction de leurs finalités :</p><h3>Cookies essentiels / strictement nécessaires:</h3><p>Ces cookies sont nécessaires pour le bon fonctionnement de notre site internet et ne peuvent pas être désactivés. Ils sont configurés en réponse aux actions que vous faites sur notre site internet, comme définir vos paramètres de confidentialité, vos identifiants de connexion ou remplir nos formulaires. Ces cookies permettent de faciliter votre navigation sur notre site internet (par exemple, revenir à une page précédente, etc.).</p><h3>Cookies non-essentiels</h3><p>Ces cookies ne sont pas nécessaires au bon fonctionnement de notre site internet mais ils nous aident à vous proposer une expérience d’utilisation améliorée et personnalisée.</p><ul><li><strong>Cookies fonctionnels:</strong><br />Grâce à ces cookies, nous pouvons vous offrir un fonctionnement et une expérience d’utilisation de notre site internet qui soient optimales et personnalisés. Ces cookies peuvent être placés sur votre ordinateur par [X] ou par des fournisseurs externes dont nous avons ajouté les services à nos pages.</li><li><strong>Cookies analytiques:</strong><br />Avec ces cookies, nous pouvons analyser les visites de notre site internet et le trafic, afin de pouvoir mesurer et améliorer les performances de notre site internet. Ces cookies nous permettent de voir quelles pages sont les plus populaires et quelles sont les habitudes de navigation de nos visiteurs.</li><li><strong>Cookies de suivi:</strong><br />Ces cookies peuvent être placés sur notre site internet par nos partenaires publicitaires. Ils peuvent être utilisés par ces entreprises pour cibler vos préférences et vous proposer des publicités pertinentes sur d’autres sites internet.</li></ul><p>Nous utilisons deux types de cookies, nos propres cookies et les cookies de partenaires soigneusement sélectionnés avec lesquels nous collaborons et qui font de la publicité pour nos services sur leur site internet.</p><h3>First Party Cookies:</h3><p>Nom de domaine: [URL]</p><div class=\\\"table-responsive\\\"><table><thead><tr><th>Nom du cookie</th><th>Type de cookie</th><th>Durée de conservation</th></tr></thead><tbody><tr><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr><tr><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr></tbody></table></div><h3>Third party cookies:</h3><p>Nom de domaine: [URL]</p><div class=\\\"table-responsive\\\"><table><thead><tr><th>Nom du cookie</th><th>Type de cookie</th><th>Durée de conservation</th></tr></thead><tbody><tr><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr><tr><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr></tbody></table></div><p>Nom de domaine: [URL]</p><div class=\\\"table-responsive\\\"><table><thead><tr><th>Nom du cookie</th><th>Type de cookie</th><th>Durée de conservation</th></tr></thead><tbody><tr><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr><tr><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr></tbody></table></div><p>Nous vous invitions à consulter notre <a href=\\\"{!! page:4 !!}\\\">Charte vie privée</a> pour plus d’information concernant le traitement de vos données personnelles par [X].</p><h2>4. Comment puis-je gérer mes cookies ?</h2><p>Veillez à ce que les cookies soient activés dans votre navigateur. Pour activer les cookies, vous devez effectuer les opérations suivantes&nbsp;:</p><p>Si votre navigateur est de type Microsoft Internet Explorer</p><ul><li>Dans Internet Explorer, cliquez sur «&nbsp;Options Internet&nbsp;» dans le menu «&nbsp;Outils&nbsp;».</li><li>Dans l’onglet «&nbsp;Confidentialité&nbsp;», cliquez sur «&nbsp;Paramètres&nbsp;» et puis sur «&nbsp;Avancé&nbsp;».</li><li>Déplacez le curseur vers le bas pour autoriser les cookies.</li><li>Cliquez sur OK.</li></ul><p>Si votre navigateur est de type Mozilla Firefox</p><ul><li>Cliquez sur le bouton «&nbsp;Menu&nbsp;» (représenté par trois barres horizontales) dans le coin supérieur droit de votre navigateur et cliquez sur «&nbsp;Préférences&nbsp;».</li><li>Sélectionnez l’onglet «&nbsp;Vie Privée&nbsp;».</li><li>Dans l’espace «&nbsp;Historique&nbsp;», sélectionnez «&nbsp;Utiliser les paramètres personnalisés pour l’historique&nbsp;».</li><li>Cochez «&nbsp;Accepter les cookies&nbsp;».</li></ul><p>Si votre navigateur est de type Google Chrome</p><ul><li>Ouvrez Chrome.</li><li>Cliquez sur l’emblème des ‘trois petits points&nbsp;superposés’ qui se trouve en haut à droite de votre écran et puis sur «&nbsp;Paramètres&nbsp;».</li></ul><ul><li>Cliquez sur «&nbsp;Paramètres avancés&nbsp;».</li><li>Cherchez la section «&nbsp;Confidentialité et sécurité&nbsp;» et cliquez sur «&nbsp;Paramètres du contenu&nbsp;».</li><li>Cliquez sur l’option «&nbsp;Cookies&nbsp;».</li><li>Sélectionnez l’option «&nbsp;Autoriser les sites à enregistrer/lire les données des cookies&nbsp;».</li></ul><p>Si votre navigateur est de type Safari</p><ul><li>Cliquez sur «&nbsp;Préférences&nbsp;» dans le menu «&nbsp;Safari&nbsp;» (que vous trouverez dans la fenêtre du navigateur Safari).</li><li>Cliquez ensuite sur l’onglet «&nbsp;Sécurité&nbsp;».</li><li>Cliquez sur «&nbsp;Accepter les cookies&nbsp;» et sur «&nbsp;Toujours&nbsp;» ou «&nbsp;Provenant seulement des sites que je visite&nbsp;».&nbsp;</li></ul><p>Si vous consultez le site internet de [X], il est recommandé d’activer les cookies. Toutefois, vous restez libre de désactiver les cookies via les paramètres de votre navigateur. Pour désactiver les cookies, vous devez effectuer les opérations suivantes&nbsp;:</p><p>Si votre navigateur est de type Microsoft Internet Explorer</p><ul><li>Dans Internet Explorer, cliquez sur «&nbsp;Options Internet&nbsp;» dans le menu «&nbsp;Outils&nbsp;».</li></ul><ul><li>Dans l’onglet «&nbsp;Confidentialité&nbsp;», cliquez sur «&nbsp;Paramètres&nbsp;» et puis sur «&nbsp;Avancé&nbsp;».</li><li>Déplacez le curseur vers le haut pour bloquer les cookies.</li><li>Cliquez sur OK.</li></ul><p>Si votre navigateur est de type Mozilla Firefox</p><ul><li>Cliquez sur le bouton «&nbsp;Menu&nbsp;» (représenté par trois barres horizontales) dans le coin supérieur droit de votre navigateur et cliquez sur «&nbsp;Préférences&nbsp;».</li><li>Sélectionnez l’onglet «&nbsp;Vie Privée&nbsp;».</li><li>Dans l’espace «&nbsp;Historique&nbsp;», sélectionnez «&nbsp;Utiliser les paramètres personnalisés pour l’historique&nbsp;».</li><li>Désactivez la case «&nbsp;Accepter les cookies&nbsp;».</li></ul><p>Si votre navigateur est de type Google Chrome</p><ul><li>Ouvrez Chrome.</li><li>Cliquez sur l’emblème des ‘trois petits points&nbsp;superposés’ qui se trouve en haut à droite de votre écran et puis sur «&nbsp;Paramètres&nbsp;».</li><li>Cliquez sur «&nbsp;Paramètres avancés&nbsp;».</li><li>Cherchez la section «&nbsp;Confidentialité et sécurité&nbsp;» et cliquez sur «&nbsp;Paramètres du contenu&nbsp;».</li><li>Cliquez sur l’option «&nbsp;Cookies&nbsp;».</li><li>Désactivez l’option «&nbsp;Autoriser les sites à enregistrer/lire les données des cookies&nbsp;».</li></ul><p>Si vous utilisez un navigateur de type Safari</p><ul><li>Cliquez sur «&nbsp;Préférences&nbsp;» dans le menu «&nbsp;Safari&nbsp;» (que vous trouverez dans la fenêtre du navigateur Safari).</li><li>Cliquez ensuite sur l’onglet «&nbsp;Sécurité&nbsp;».</li><li>Choisissez de bloquer les Cookies.&nbsp;&nbsp;</li></ul><h2>5. Quels sont mes droits?</h2><p>Dès lors que les cookies peuvent impliquer un traitement de vos données personnelles, vous disposez du droit à un traitement légitime et sécurisé de vos données personnelles. En tant que sujet concerné par le traitement de vos données personnelles, vous disposez des droits suivants&nbsp;:</p><ul><li>Droit d’opposition : s’il existe des raisons impérieuses et légitimes, vous pouvez vous opposer au traitement de vos données personnelles.</li><li>Droit d’accès : toute personne qui prouve son identité a un droit d’accès aux informations relatives à l’existence ou non d’un traitement de ses données personnelles, ainsi qu’aux informations relatives aux finalités du traitement, aux catégories de données traitées, aux catégories de destinataires auxquels les données sont communiquées et à la durée de conservation des données personnelles.</li><li>Droit de correction&nbsp;: les données personnelles inexactes ou incomplètes peuvent toujours être corrigées, ou même effacées, sur demande de la personne concernée.</li></ul><p>L’exercice de ces droits se fait toujours conformément aux modalités prévues dans notre <a href=\\\"{!! page:4 !!}\\\">Charte vie privée</a>. Si, après avoir lu le présent document, vous avez encore des questions ou des remarques concernant les cookies, vous pouvez toujours nous contacter à [EMAIL].</p>\", \"nl\": \"<h1>Cookieverklaring</h1><h2>1. Cookies</h2><p>Cookies zijn kleine data- of tekstbestanden die door websites en applicaties op uw lokale computer worden geplaatst. Dergelijke cookies kunnen verschillende doeleinden hebben: er zijn technische cookies (bijvoorbeeld voor het bijhouden van taalinstellingen), sessiecookies (tijdelijke cookies die verlopen na één sessie) en tracking cookies (cookies die uw gedrag op het internet volgen en bijhouden, om u op die manier een meer optimale gebruikservaring te kunnen aanbieden).</p><p>De Belgische Wet betreffende de elektronische communicatie van 13 juni 2005 bevat enkele bepalingen rond cookies en het gebruik ervan op websites. De wet is een omzetting van de Europese e-Privacyrichtlijn, wat betekent dat de cookiewetgeving verschillend kan geïmplementeerd worden in andere Europese lidstaten.</p><p>[X] is gevestigd in België en volgt bijgevolg de Belgische wetgeving inzake cookies.</p><h2>2. Doel en nut van cookies</h2><p>[X] wil elke bezoeker van het platform/de website zo goed mogelijk informeren over zijn rechten onder de Belgische wetgeving inzake cookies, en over welke cookies [X] gebruikt. Door het platform/de website te gebruiken gaat de bezoeker akkoord met het gebruik van cookies. Cookies helpen [X] om uw bezoek aan het platform/de website te optimaliseren, om technische keuzes te herinneren (bijvoorbeeld een taalkeuze, een nieuwsbrief, et cetera) en om u meer relevante diensten en aanbiedingen te tonen.</p><p>Als u het platform/de website van [X] wil consulteren, is het aan te raden dat de technische instellingen voor cookies ingeschakeld werden. Zonder ingeschakelde cookies kan [X] geen probleemloos bezoek op het platform/de website garanderen. Indien u de cookies liever niet wenst, bent u als bezoeker vrij om de cookies uit te schakelen.</p><p>Wij gebruiken cookies om uw bezoek aan ons platform/onze website te verbeteren. De cookies die wij gebruiken zijn veilig. De informatie die we verzamelen met behulp van cookies helpt ons om eventuele fouten te identificeren of om u specifieke diensten te laten zien waarvan wij denken dat ze voor u van belang kunnen zijn.</p><h2>3. Soorten cookies gebruikt door [X]</h2><p>We onderscheiden volgende types cookies, naargelang hun doeleinden:</p><h3>Essentiële / Strikt noodzakelijke cookies:</h3><p>Deze cookies zijn nodig om het platform/de website te laten functioneren en kunnen niet worden uitgeschakeld in onze systemen. Ze worden meestal alleen ingesteld als reactie op acties die door u zijn gesteld, zoals het instellen van uw privacyvoorkeuren, inloggen of het invullen van formulieren. Ze zijn noodzakelijk voor een goede communicatie en ze vergemakkelijken het navigeren (bijvoorbeeld naar een vorige pagina terugkeren, etc.).</p><h3>Niet-essentiële cookies:</h3><p>Deze cookies zijn op zich niet noodzakelijk om het platform/de website te laten functioneren, maar ze helpen ons wel een verbeterde en gepersonaliseerde website aan te bieden.</p><ul><li><strong>Functionele cookies:</strong><br />Deze cookies stellen het platform/de website in staat om verbeterde functionaliteit en personalisatie te bieden. Ze kunnen worden ingesteld door ons of door externe providers wiens diensten we hebben toegevoegd aan onze pagina’s.</li><li><strong>Analytische cookies:</strong><br />Met deze cookies kunnen we bezoeken en traffic bijhouden, zodat we de prestaties van ons platform/onze website kunnen meten en verbeteren. Ze helpen ons te weten welke pagina’s het meest en het minst populair zijn en hoe bezoekers zich door het platform/de website verplaatsen.</li><li><strong>Targeting / advertising cookies:</strong><br />Deze cookies kunnen door onze advertentiepartners via ons platform/onze website worden ingesteld. Ze kunnen door die bedrijven worden gebruikt om een profiel van uw interesses samen te stellen en u relevante advertenties op andere sites te laten zien.</li></ul><p>Wij gebruiken enerzijds onze eigen cookies&nbsp;(First Party cookies) en anderzijds cookies&nbsp;(Third Party cookies) van zorgvuldig geselecteerde partners met wie we samenwerken en die onze diensten op hun website adverteren.</p><h3>First Party Cookies:</h3><p><strong>Domeinnaam: [URL]</strong></p><div class=\\\"table-responsive\\\"><table><tbody><tr><td>Naam cookie</td><td>Type cookie</td><td>Bewaarduur</td></tr><tr><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr><tr><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr></tbody></table></div><h3>Third party cookies:</h3><p><strong>Domeinnaam: [URL]</strong></p><div class=\\\"table-responsive\\\"><table><tbody><tr><td>Naam cookie</td><td>Type cookie</td><td>Bewaarduur</td></tr><tr><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr><tr><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr></tbody></table></div><p><strong>Domeinnaam: [URL]</strong></p><div class=\\\"table-responsive\\\"><table><tbody><tr><td>Naam cookie</td><td>Type cookie</td><td>Bewaarduur</td></tr><tr><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr><tr><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr></tbody></table></div><p>Neem kennis van ons <a href=\\\"{!! page:4 !!}\\\">Privacyverklaring</a> voor meer informatie omtrent de verwerking van persoonsgegevens door [X].</p><h2>4. Beheer van de cookies</h2><p>Zorg ervoor dat cookies zijn ingeschakeld in uw browser. Om cookies in te schakelen moeten de volgende handelingen uitgevoerd worden:</p><p>Bij browser - Microsoft Internet Explorer</p><ul><li>In Internet Explorer, klik op ‘Internetopties’ in het menu ‘Extra’.</li><li>Op het tabblad ‘Privacy’, verplaats de instellingen- schuifknop naar ‘laag’ of ‘accepteer alle cookies’ (instelling boven ‘medium’ schakelt cookies uit).</li><li>Klik op ‘OK’.</li></ul><p>Bij browser - Mozilla Firefox</p><ul><li>Klik op ‘Firefox’ in de linkerbovenhoek van uw browser en klik vervolgens op ‘Opties’.</li><li>Op het tabblad ‘Privacy’, zorg ervoor dat de ‘Websites laten weten dat ik niet gevolgd wil worden’ niet is aangevinkt.</li><li>Klik op ‘OK’.</li></ul><p>Bij browser - Google Chrome</p><ul><li>Klik op de drie puntjes naast de browserbalk bovenaan in uw browservenster en kies ‘Opties’.</li><li>Zoek het gedeelte ‘Privacy and security’ en klik op ‘content settings’.</li><li>Klik op de optie ‘cookies’.</li><li>Selecteer nu ‘Allow sites to save and read cookie data’.</li></ul><p>Bij browser - Safari</p><ul><li>Kies ‘Voorkeuren’ in het taakmenu. (Het taakmenu bevindt zich rechtsboven in het Safari-venster en ziet eruit als een tandwiel of klik op ‘Safari’ in het uitgebreide taakmenu.)</li><li>Klik op het Privacy tabblad. Zoek de sectie genaamd ‘Cookies en andere websitegegevens’</li><li>Duid aan dat u cookies aanvaardt.</li></ul><p>Als u het platform/de website van [X] wil consulteren, is het aan te raden dat u cookies ingeschakeld hebt. Echter, als u dit liever niet wenst, bent u als bezoeker vrij om de cookies uit te schakelen via uw browserinstellingen. Dit kan via volgende manieren:</p><p>Bij browser - Microsoft Internet Explorer</p><ul><li>Selecteer in Internet Explorer de knop Extra en selecteer Internetopties.</li><li>Selecteer het tabblad Privacy en verplaats onder Instellingen de schuifregelaar naar boven om alle cookies te blokkeren.</li><li>Klik op OK.</li></ul><p>Bij browser - Mozilla Firefox</p><ul><li>Klik op de menuknop en kies ‘Voorkeuren’.</li><li>Selecteer het paneel ‘Privacy &amp; Beveiliging’ en ga naar de sectie ‘Geschiedenis’.</li><li>Stel naast ‘Firefox zal’ in op ‘Aangepaste instellingen gebruiken voor geschiedenis’.</li><li>Stel&nbsp;‘Cookies van derden accepteren’&nbsp;in op&nbsp;‘Nooit’.</li><li>Sluit de pagina&nbsp;‘about: preferences’. Wijzigingen die u hebt aangebracht, worden automatisch opgeslagen.</li></ul><p>Bij browser - Google Chrome</p><ul><li>Selecteer ‘Meer Instellingen’ in de browserwerkbalk.</li><li>Selecteer onderaan de pagina de optie ‘Geavanceerd’.</li><li>Selecteer bij ‘Privacy en beveiliging’ de optie ‘Instellingen voor content’.</li><li>Selecteer ‘Cookies’.</li><li>Schakel ‘Sites toestaan cookiegegevens op te slaan en te lezen’ uit.</li></ul><p>Bij browser - Safari</p><ul><li>Kies ‘Voorkeuren’ in het taakmenu. (Het taakmenu bevindt zich rechtsboven in het Safari-venster en ziet eruit als een tandwiel of klik op ‘Safari’ in het uitgebreide taakmenu.)</li><li>Klik op het Privacy tabblad. Zoek de sectie genaamd ‘Cookies en andere websitegegevens’</li><li>Duid aan dat u cookies niet aanvaardt.</li></ul><p>Of raadpleeg hiervoor de help-functie van uw internetbrowser.</p><h2>5. Rechten van de bezoekers</h2><p>Aangezien cookies een verwerking van persoonsgegevens kunnen uitmaken, heeft u als betrokkene recht op de rechtmatige en veilige verwerking van de persoonsgegevens. Als betrokkene kan u volgende rechten uitoefenen:</p><ul><li>Recht op verzet: Indien er sprake is van een zwaarwegende en gerechtvaardigde redenen kan men zich verzetten tegen de verwerking van persoonsgegevens.</li><li>Recht op toegang: Iedere betrokkene die zijn identiteit bewijst, beschikt over een recht op toegang tot de informatie rond het al dan niet bestaan van verwerkingen van zijn persoonsgegevens, net als de doeleinden van deze verwerking, de categorieën van gegevens waarop deze verwerkingen betrekking hebben en de categorieën van ontvangers aan wie de gegevens worden verstrekt.</li><li>Recht op verbetering: Onnauwkeurige of onvolledige persoonsgegevens kunnen op verzoek van de betrokkene steeds verbeterd of zelfs uitgewist worden.</li></ul><p>De uitoefening van deze rechten gebeurt conform de modaliteiten zoals bepaald in onze <a href=\\\"{!! page:4 !!}\\\">Privacyverklaring</a>. Meer informatie over de rechten van bezoekers vindt u ook in de <a href=\\\"{!! page:4 !!}\\\">Privacyverklaring</a>. Mocht u na het lezen van deze Cookieverklaring toch nog vragen of opmerkingen rond cookies hebben, kan u steeds contact opnemen via [EMAIL].</p>\"}', '{\"en\": 1, \"fr\": 1, \"nl\": 1}', '{\"en\": null, \"fr\": null, \"nl\": null}', '{\"en\": null, \"fr\": null, \"nl\": null}', NULL, NULL, NULL, NULL, '2021-01-20 08:53:43', '2021-01-20 08:53:43');

-- --------------------------------------------------------

--
-- Table structure for table `typicms_page_sections`
--

CREATE TABLE `typicms_page_sections` (
  `id` int(10) UNSIGNED NOT NULL,
  `page_id` int(10) UNSIGNED NOT NULL,
  `image_id` int(10) UNSIGNED DEFAULT NULL,
  `position` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `status` json NOT NULL,
  `title` json NOT NULL,
  `slug` json NOT NULL,
  `body` json NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `typicms_password_resets`
--

CREATE TABLE `typicms_password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `typicms_permissions`
--

CREATE TABLE `typicms_permissions` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `guard_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `typicms_permissions`
--

INSERT INTO `typicms_permissions` (`id`, `name`, `guard_name`, `created_at`, `updated_at`) VALUES
(1, 'view-navbar', 'web', NULL, NULL),
(2, 'see-dashboard', 'web', NULL, NULL),
(3, 'see-history', 'web', NULL, NULL),
(4, 'see-settings', 'web', NULL, NULL),
(5, 'update-setting', 'web', NULL, NULL),
(6, 'clear-history', 'web', NULL, NULL),
(7, 'change-locale', 'web', NULL, NULL),
(8, 'update-preferences', 'web', NULL, NULL),
(9, 'clear-cache', 'web', NULL, NULL),
(10, 'see-all-blocks', 'web', NULL, NULL),
(11, 'create-block', 'web', NULL, NULL),
(12, 'update-block', 'web', NULL, NULL),
(13, 'delete-block', 'web', NULL, NULL),
(14, 'see-all-files', 'web', NULL, NULL),
(15, 'create-file', 'web', NULL, NULL),
(16, 'update-file', 'web', NULL, NULL),
(17, 'delete-file', 'web', NULL, NULL),
(18, 'see-all-galleries', 'web', NULL, NULL),
(19, 'create-gallery', 'web', NULL, NULL),
(20, 'update-gallery', 'web', NULL, NULL),
(21, 'delete-gallery', 'web', NULL, NULL),
(22, 'see-all-menus', 'web', NULL, NULL),
(23, 'create-menu', 'web', NULL, NULL),
(24, 'update-menu', 'web', NULL, NULL),
(25, 'delete-menu', 'web', NULL, NULL),
(26, 'see-all-pages', 'web', NULL, NULL),
(27, 'create-page', 'web', NULL, NULL),
(28, 'update-page', 'web', NULL, NULL),
(29, 'delete-page', 'web', NULL, NULL),
(30, 'see-all-roles', 'web', NULL, NULL),
(31, 'create-role', 'web', NULL, NULL),
(32, 'update-role', 'web', NULL, NULL),
(33, 'delete-role', 'web', NULL, NULL),
(34, 'see-all-translations', 'web', NULL, NULL),
(35, 'create-translation', 'web', NULL, NULL),
(36, 'update-translation', 'web', NULL, NULL),
(37, 'delete-translation', 'web', NULL, NULL),
(38, 'see-all-users', 'web', NULL, NULL),
(39, 'create-user', 'web', NULL, NULL),
(40, 'update-user', 'web', NULL, NULL),
(41, 'delete-user', 'web', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `typicms_permission_role`
--

CREATE TABLE `typicms_permission_role` (
  `permission_id` bigint(20) UNSIGNED NOT NULL,
  `role_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `typicms_permission_role`
--

INSERT INTO `typicms_permission_role` (`permission_id`, `role_id`) VALUES
(1, 1),
(2, 1),
(3, 1),
(4, 1),
(5, 1),
(6, 1),
(7, 1),
(8, 1),
(9, 1),
(10, 1),
(11, 1),
(12, 1),
(13, 1),
(14, 1),
(15, 1),
(16, 1),
(17, 1),
(18, 1),
(19, 1),
(20, 1),
(21, 1),
(22, 1),
(23, 1),
(24, 1),
(25, 1),
(26, 1),
(27, 1),
(28, 1),
(29, 1),
(30, 1),
(31, 1),
(32, 1),
(33, 1),
(34, 1),
(35, 1),
(36, 1),
(37, 1),
(38, 1),
(39, 1),
(40, 1),
(41, 1);

-- --------------------------------------------------------

--
-- Table structure for table `typicms_permission_user`
--

CREATE TABLE `typicms_permission_user` (
  `permission_id` bigint(20) UNSIGNED NOT NULL,
  `model_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `typicms_roles`
--

CREATE TABLE `typicms_roles` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `guard_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `typicms_roles`
--

INSERT INTO `typicms_roles` (`id`, `name`, `guard_name`, `created_at`, `updated_at`) VALUES
(1, 'administrator', 'web', '2021-01-20 08:53:43', '2021-01-20 08:53:43'),
(2, 'visitor', 'web', '2021-01-20 08:53:43', '2021-01-20 08:53:43');

-- --------------------------------------------------------

--
-- Table structure for table `typicms_role_user`
--

CREATE TABLE `typicms_role_user` (
  `role_id` bigint(20) UNSIGNED NOT NULL,
  `model_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `typicms_settings`
--

CREATE TABLE `typicms_settings` (
  `id` int(10) UNSIGNED NOT NULL,
  `group_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'config',
  `key_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `typicms_settings`
--

INSERT INTO `typicms_settings` (`id`, `group_name`, `key_name`, `value`, `created_at`, `updated_at`) VALUES
(1, 'config', 'webmaster_email', 'info@example.com', '2021-01-20 08:53:43', '2021-01-20 08:53:43'),
(2, 'config', 'google_analytics_code', NULL, '2021-01-20 08:53:43', '2021-01-20 08:53:43'),
(3, 'config', 'lang_chooser', '1', '2021-01-20 08:53:43', '2021-01-20 08:53:43'),
(4, 'fr', 'website_title', 'Site web sans titre', '2021-01-20 08:53:43', '2021-01-20 08:53:43'),
(5, 'fr', 'status', '1', '2021-01-20 08:53:43', '2021-01-20 08:53:43'),
(6, 'nl', 'website_title', 'Untitled website', '2021-01-20 08:53:43', '2021-01-20 08:53:43'),
(7, 'nl', 'status', '1', '2021-01-20 08:53:43', '2021-01-20 08:53:43'),
(8, 'en', 'website_title', 'Untitled website', '2021-01-20 08:53:43', '2021-01-20 08:53:43'),
(9, 'en', 'status', '1', '2021-01-20 08:53:43', '2021-01-20 08:53:43'),
(10, 'config', 'welcome_message', 'Welcome to the administration panel of TypiCMS.', '2021-01-20 08:53:43', '2021-01-20 08:53:43'),
(11, 'config', 'auth_public', '0', '2021-01-20 08:53:43', '2021-01-20 08:53:43'),
(12, 'config', 'register', '0', '2021-01-20 08:53:43', '2021-01-20 08:53:43'),
(13, 'config', 'admin_locale', 'en', '2021-01-20 08:53:43', '2021-01-20 08:53:43');

-- --------------------------------------------------------

--
-- Table structure for table `typicms_taggables`
--

CREATE TABLE `typicms_taggables` (
  `id` int(10) UNSIGNED NOT NULL,
  `tag_id` int(10) UNSIGNED NOT NULL,
  `taggable_id` int(10) UNSIGNED NOT NULL,
  `taggable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `typicms_tags`
--

CREATE TABLE `typicms_tags` (
  `id` int(10) UNSIGNED NOT NULL,
  `tag` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `typicms_translations`
--

CREATE TABLE `typicms_translations` (
  `id` int(10) UNSIGNED NOT NULL,
  `group` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `translation` json NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `typicms_translations`
--

INSERT INTO `typicms_translations` (`id`, `group`, `key`, `translation`, `created_at`, `updated_at`) VALUES
(1, 'db', 'More', '{\"en\": \"More\", \"fr\": \"En savoir plus\", \"nl\": \"Meer\"}', '2021-01-20 08:53:43', '2021-01-20 08:53:43'),
(2, 'db', 'Skip to content', '{\"en\": \"Skip to content\", \"fr\": \"Aller au contenu\", \"nl\": \"Naar inhoud\"}', '2021-01-20 08:53:43', '2021-01-20 08:53:43'),
(3, 'db', 'languages.fr', '{\"en\": \"Français\", \"fr\": \"Français\", \"nl\": \"Français\"}', '2021-01-20 08:53:43', '2021-01-20 08:53:43'),
(4, 'db', 'languages.en', '{\"en\": \"English\", \"fr\": \"English\", \"nl\": \"English\"}', '2021-01-20 08:53:43', '2021-01-20 08:53:43'),
(5, 'db', 'languages.nl', '{\"en\": \"Nederlands\", \"fr\": \"Nederlands\", \"nl\": \"Nederlands\"}', '2021-01-20 08:53:43', '2021-01-20 08:53:43'),
(6, 'db', 'Search', '{\"en\": \"Search\", \"fr\": \"Chercher\", \"nl\": \"Zoeken\"}', '2021-01-20 08:53:43', '2021-01-20 08:53:43'),
(7, 'db', 'message when contact form is sent', '{\"en\": \"Thank you\", \"fr\": \"Merci\", \"nl\": \"Dank u\"}', '2021-01-20 08:53:43', '2021-01-20 08:53:43'),
(8, 'db', 'message when errors in form', '{\"en\": \"Please correct the errors below\", \"fr\": \"Veuillez s’il vous plaît corriger les erreurs ci-dessous\", \"nl\": \"Gelieve de onderstaande fouten te corrigeren\"}', '2021-01-20 08:53:43', '2021-01-20 08:53:43'),
(9, 'db', 'Add to calendar', '{\"en\": \"Add to calendar\", \"fr\": \"Ajouter au calendrier\", \"nl\": \"Toevoegen aan Agenda\"}', '2021-01-20 08:53:43', '2021-01-20 08:53:43'),
(10, 'db', 'All news', '{\"en\": \"All news\", \"fr\": \"Toutes les actualités\", \"nl\": \"Alle nieuws\"}', '2021-01-20 08:53:43', '2021-01-20 08:53:43'),
(11, 'db', 'All events', '{\"en\": \"All events\", \"fr\": \"Tous les événements\", \"nl\": \"Alle evenementen\"}', '2021-01-20 08:53:43', '2021-01-20 08:53:43'),
(12, 'db', 'Partners', '{\"en\": \"Partners\", \"fr\": \"Partenaires\", \"nl\": \"Partners\"}', '2021-01-20 08:53:43', '2021-01-20 08:53:43'),
(13, 'db', 'Latest news', '{\"en\": \"Latest news\", \"fr\": \"Dernières actualités\", \"nl\": \"Laatste Nieuws\"}', '2021-01-20 08:53:43', '2021-01-20 08:53:43'),
(14, 'db', 'Upcoming events', '{\"en\": \"Upcoming events\", \"fr\": \"Prochains événements\", \"nl\": \"Aankomende evenementen\"}', '2021-01-20 08:53:43', '2021-01-20 08:53:43'),
(16, 'db', 'Error :code', '{\"en\": \"Error :code\", \"fr\": \"Erreur :code\", \"nl\": \"Error :code\"}', '2021-01-20 08:53:43', '2021-01-20 08:53:43'),
(17, 'db', 'Sorry, you are not authorized to view this page', '{\"en\": \"Sorry, you are not authorized to view this page\", \"fr\": \"Désolé, vous n’êtes pas autorisé à voir cette page\", \"nl\": \"Sorry, u bent niet bevoegd om deze pagina te bekijken\"}', '2021-01-20 08:53:43', '2021-01-20 08:53:43'),
(18, 'db', 'Go to our homepage?', '{\"en\": \"Go to our :a_openhomepage:a_close?\", \"fr\": \"Souhaitez-vous visiter notre :a_openpage d’accueil:a_close ?\", \"nl\": \"Wilt u onze :a_openhomepage:a_close te bezoeken?\"}', '2021-01-20 08:53:43', '2021-01-20 08:53:43'),
(19, 'db', 'Sorry, this page was not found', '{\"en\": \"Sorry, this page was not found\", \"fr\": \"Désolé, cette page n’a pas été trouvée\", \"nl\": \"Sorry, deze pagina is niet gevonden\"}', '2021-01-20 08:53:43', '2021-01-20 08:53:43'),
(20, 'db', 'Sorry, a server error occurred', '{\"en\": \"Sorry, a server error occurred\", \"fr\": \"Désolé, une erreur serveur est survenue\", \"nl\": \"Sorry, er is een serverfout opgetreden\"}', '2021-01-20 08:53:43', '2021-01-20 08:53:43'),
(21, 'db', 'Open navigation', '{\"en\": \"Open navigation\", \"fr\": \"Aller à la navigation\", \"nl\": \"Open navigatie\"}', '2021-01-20 08:53:43', '2021-01-20 08:53:43');

-- --------------------------------------------------------

--
-- Table structure for table `typicms_users`
--

CREATE TABLE `typicms_users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `activated` tinyint(1) NOT NULL DEFAULT '0',
  `superuser` tinyint(1) NOT NULL DEFAULT '0',
  `first_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `locale` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `preferences` text COLLATE utf8mb4_unicode_ci,
  `api_token` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `typicms_users`
--

INSERT INTO `typicms_users` (`id`, `email`, `password`, `activated`, `superuser`, `first_name`, `last_name`, `locale`, `preferences`, `api_token`, `email_verified_at`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'test@test.com', '$2y$10$eODMnJlI54acPDluiCWlVuObtGaZgZ3q6xb3tg6KE66RtrvtekEum', 1, 1, 'Dev', 'Q', NULL, NULL, '23d4c0b0-f6e1-44da-8c65-2a92a2192a1f', '2021-01-20 08:54:15', NULL, '2021-01-20 08:54:15', '2021-01-20 09:01:28');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `typicms_blocks`
--
ALTER TABLE `typicms_blocks`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `typicms_files`
--
ALTER TABLE `typicms_files`
  ADD PRIMARY KEY (`id`),
  ADD KEY `typicms_files_folder_id_foreign` (`folder_id`);

--
-- Indexes for table `typicms_history`
--
ALTER TABLE `typicms_history`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `typicms_menulinks`
--
ALTER TABLE `typicms_menulinks`
  ADD PRIMARY KEY (`id`),
  ADD KEY `typicms_menulinks_menu_id_foreign` (`menu_id`),
  ADD KEY `typicms_menulinks_parent_id_foreign` (`parent_id`);

--
-- Indexes for table `typicms_menus`
--
ALTER TABLE `typicms_menus`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `typicms_migrations`
--
ALTER TABLE `typicms_migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `typicms_model_has_files`
--
ALTER TABLE `typicms_model_has_files`
  ADD PRIMARY KEY (`file_id`,`model_id`,`model_type`),
  ADD KEY `file` (`model_type`,`model_id`);

--
-- Indexes for table `typicms_pages`
--
ALTER TABLE `typicms_pages`
  ADD PRIMARY KEY (`id`),
  ADD KEY `typicms_pages_parent_id_foreign` (`parent_id`);

--
-- Indexes for table `typicms_page_sections`
--
ALTER TABLE `typicms_page_sections`
  ADD PRIMARY KEY (`id`),
  ADD KEY `typicms_page_sections_page_id_foreign` (`page_id`);

--
-- Indexes for table `typicms_password_resets`
--
ALTER TABLE `typicms_password_resets`
  ADD KEY `typicms_password_resets_email_index` (`email`),
  ADD KEY `typicms_password_resets_token_index` (`token`);

--
-- Indexes for table `typicms_permissions`
--
ALTER TABLE `typicms_permissions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `typicms_permission_role`
--
ALTER TABLE `typicms_permission_role`
  ADD PRIMARY KEY (`permission_id`,`role_id`),
  ADD KEY `typicms_permission_role_role_id_foreign` (`role_id`);

--
-- Indexes for table `typicms_permission_user`
--
ALTER TABLE `typicms_permission_user`
  ADD PRIMARY KEY (`permission_id`,`model_id`,`model_type`),
  ADD KEY `model_has_permissions_model_id_model_type_index` (`model_id`,`model_type`);

--
-- Indexes for table `typicms_roles`
--
ALTER TABLE `typicms_roles`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `typicms_role_user`
--
ALTER TABLE `typicms_role_user`
  ADD PRIMARY KEY (`role_id`,`model_id`,`model_type`),
  ADD KEY `model_has_roles_model_id_model_type_index` (`model_id`,`model_type`);

--
-- Indexes for table `typicms_settings`
--
ALTER TABLE `typicms_settings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `typicms_taggables`
--
ALTER TABLE `typicms_taggables`
  ADD PRIMARY KEY (`id`),
  ADD KEY `typicms_taggables_tag_id_foreign` (`tag_id`);

--
-- Indexes for table `typicms_tags`
--
ALTER TABLE `typicms_tags`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `typicms_translations`
--
ALTER TABLE `typicms_translations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `typicms_users`
--
ALTER TABLE `typicms_users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `typicms_users_email_unique` (`email`),
  ADD UNIQUE KEY `typicms_users_api_token_unique` (`api_token`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `typicms_blocks`
--
ALTER TABLE `typicms_blocks`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `typicms_files`
--
ALTER TABLE `typicms_files`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `typicms_history`
--
ALTER TABLE `typicms_history`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `typicms_menulinks`
--
ALTER TABLE `typicms_menulinks`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `typicms_menus`
--
ALTER TABLE `typicms_menus`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `typicms_migrations`
--
ALTER TABLE `typicms_migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `typicms_pages`
--
ALTER TABLE `typicms_pages`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `typicms_page_sections`
--
ALTER TABLE `typicms_page_sections`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `typicms_permissions`
--
ALTER TABLE `typicms_permissions`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=42;

--
-- AUTO_INCREMENT for table `typicms_roles`
--
ALTER TABLE `typicms_roles`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `typicms_settings`
--
ALTER TABLE `typicms_settings`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `typicms_taggables`
--
ALTER TABLE `typicms_taggables`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `typicms_tags`
--
ALTER TABLE `typicms_tags`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `typicms_translations`
--
ALTER TABLE `typicms_translations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `typicms_users`
--
ALTER TABLE `typicms_users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `typicms_files`
--
ALTER TABLE `typicms_files`
  ADD CONSTRAINT `typicms_files_folder_id_foreign` FOREIGN KEY (`folder_id`) REFERENCES `typicms_files` (`id`);

--
-- Constraints for table `typicms_menulinks`
--
ALTER TABLE `typicms_menulinks`
  ADD CONSTRAINT `typicms_menulinks_menu_id_foreign` FOREIGN KEY (`menu_id`) REFERENCES `typicms_menus` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `typicms_menulinks_parent_id_foreign` FOREIGN KEY (`parent_id`) REFERENCES `typicms_menulinks` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `typicms_model_has_files`
--
ALTER TABLE `typicms_model_has_files`
  ADD CONSTRAINT `typicms_model_has_files_file_id_foreign` FOREIGN KEY (`file_id`) REFERENCES `typicms_files` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `typicms_pages`
--
ALTER TABLE `typicms_pages`
  ADD CONSTRAINT `typicms_pages_parent_id_foreign` FOREIGN KEY (`parent_id`) REFERENCES `typicms_pages` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `typicms_page_sections`
--
ALTER TABLE `typicms_page_sections`
  ADD CONSTRAINT `typicms_page_sections_page_id_foreign` FOREIGN KEY (`page_id`) REFERENCES `typicms_pages` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `typicms_permission_role`
--
ALTER TABLE `typicms_permission_role`
  ADD CONSTRAINT `typicms_permission_role_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `typicms_permissions` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `typicms_permission_role_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `typicms_roles` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `typicms_permission_user`
--
ALTER TABLE `typicms_permission_user`
  ADD CONSTRAINT `typicms_permission_user_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `typicms_permissions` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `typicms_role_user`
--
ALTER TABLE `typicms_role_user`
  ADD CONSTRAINT `typicms_role_user_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `typicms_roles` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `typicms_taggables`
--
ALTER TABLE `typicms_taggables`
  ADD CONSTRAINT `typicms_taggables_tag_id_foreign` FOREIGN KEY (`tag_id`) REFERENCES `typicms_tags` (`id`) ON DELETE CASCADE;
--
-- Database: `hdts`
--
CREATE DATABASE IF NOT EXISTS `hdts` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `hdts`;

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `name` varchar(60) NOT NULL,
  `user_name` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `name`, `user_name`, `password`) VALUES
(1, 'admin', 'admin', 'admin'),
(2, 'admin', 'admin', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `tickets`
--

CREATE TABLE `tickets` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `msg` text NOT NULL,
  `email` varchar(255) NOT NULL,
  `created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` enum('open','closed','resolved') NOT NULL DEFAULT 'open'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tickets`
--

INSERT INTO `tickets` (`id`, `title`, `msg`, `email`, `created`, `status`) VALUES
(1, 'Test Ticket', 'This is your first ticket.', 'support@support.com', '2020-06-10 13:06:17', 'resolved'),
(2, 'let try', 'just a try it', 'exam@mail.com', '2021-01-24 16:31:40', 'resolved'),
(3, 'عنوان', 'رسالة المشكلة', 'test@test.com', '2021-01-24 18:39:30', 'open'),
(4, 'title of problem', 'the message of problem xxxxxxx', 'email@mail.com', '2021-01-24 18:43:27', 'closed');

-- --------------------------------------------------------

--
-- Table structure for table `tickets_comments`
--

CREATE TABLE `tickets_comments` (
  `id` int(11) NOT NULL,
  `ticket_id` int(11) NOT NULL,
  `msg` text NOT NULL,
  `created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tickets_comments`
--

INSERT INTO `tickets_comments` (`id`, `ticket_id`, `msg`, `created`) VALUES
(1, 1, 'This is a test comment.', '2020-06-10 16:23:39'),
(2, 2, 'ok try', '2021-01-24 16:31:56'),
(3, 2, '2nd test\r\ntwo line', '2021-01-24 17:00:00'),
(4, 1, 'admin comment', '2021-01-24 18:36:36'),
(5, 1, 'hi', '2021-01-24 18:38:17'),
(6, 3, 'اضافات كلام', '2021-01-24 18:39:46'),
(7, 4, 'user can add comment to ticket\r\n', '2021-01-24 18:43:50'),
(8, 4, 'admin can reply on tick', '2021-01-24 18:45:12');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tickets`
--
ALTER TABLE `tickets`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tickets_comments`
--
ALTER TABLE `tickets_comments`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tickets`
--
ALTER TABLE `tickets`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tickets_comments`
--
ALTER TABLE `tickets_comments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- Database: `jawdat_alnaseej`
--
CREATE DATABASE IF NOT EXISTS `jawdat_alnaseej` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `jawdat_alnaseej`;
--
-- Database: `khms`
--
CREATE DATABASE IF NOT EXISTS `khms` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `khms`;

-- --------------------------------------------------------

--
-- Table structure for table `donate`
--

CREATE TABLE `donate` (
  `id` int(11) NOT NULL,
  `name` varchar(191) NOT NULL,
  `SorC` varchar(191) NOT NULL,
  `phone` int(11) NOT NULL,
  `email` varchar(191) NOT NULL,
  `street` varchar(191) NOT NULL,
  `city` varchar(191) NOT NULL,
  `zip` int(11) NOT NULL,
  `medicinename` varchar(191) NOT NULL,
  `medicinequan` int(11) NOT NULL,
  `medicinedate` varchar(191) NOT NULL,
  `medicinegetway` varchar(191) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `donate`
--

INSERT INTO `donate` (`id`, `name`, `SorC`, `phone`, `email`, `street`, `city`, `zip`, `medicinename`, `medicinequan`, `medicinedate`, `medicinegetway`) VALUES
(31764773, 'test', 'group', 1234567890, 'test@test.test', 'test', 'makkah', 12345, 'test', 3, '2021-02-25', 'givePoint'),
(255811334, 'test', 'group', 1234567890, 'test@test.test', 'test', 'makkah', 12345, 'test', 3, '2021-02-25', 'givePoint'),
(379021569, 'test', 'group', 1234567890, 'test@test.test', 'test', 'makkah', 12345, 'test', 3, '2021-02-25', 'givePoint'),
(440153863, 'test', 'group', 1234567890, 'test@test.test', 'test', 'makkah', 12345, 'test', 3, '2021-02-25', 'givePoint'),
(1191016247, 'test', 'group', 1234567890, 'xxx@xxx.xxx', 'test', 'makkah', 12345, 'test', 6, '2021-03-01', 'delivary'),
(1714036704, 'test', 'group', 1234567890, 'test@test.test', 'test', 'makkah', 12345, 'test', 3, '2021-02-25', 'givePoint');

-- --------------------------------------------------------

--
-- Table structure for table `employees`
--

CREATE TABLE `employees` (
  `id` int(11) NOT NULL,
  `name` varchar(191) NOT NULL,
  `username` varchar(191) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` varchar(191) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `employees`
--

INSERT INTO `employees` (`id`, `name`, `username`, `password`, `role`) VALUES
(1, 'admin', 'admin', 'admin', 'manager'),
(3, 'employer', 'emp', 'emp123', 'employer');

-- --------------------------------------------------------

--
-- Table structure for table `needy`
--

CREATE TABLE `needy` (
  `id` int(11) NOT NULL,
  `name` varchar(191) NOT NULL,
  `national-id` int(11) NOT NULL,
  `phone` int(11) NOT NULL,
  `group-followed` varchar(191) NOT NULL,
  `street` varchar(191) NOT NULL,
  `city` varchar(191) NOT NULL,
  `zip` int(11) NOT NULL,
  `midicane-req` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `needy`
--

INSERT INTO `needy` (`id`, `name`, `national-id`, `phone`, `group-followed`, `street`, `city`, `zip`, `midicane-req`) VALUES
(707997970, 'test', 1231231212, 1234567890, 'no any group', 'test', 'makkah', 12345, 'khme-logo.jpeg');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `donate`
--
ALTER TABLE `donate`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `employees`
--
ALTER TABLE `employees`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `needy`
--
ALTER TABLE `needy`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `donate`
--
ALTER TABLE `donate`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1714036705;

--
-- AUTO_INCREMENT for table `employees`
--
ALTER TABLE `employees`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `needy`
--
ALTER TABLE `needy`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=707997971;
--
-- Database: `rehla`
--
CREATE DATABASE IF NOT EXISTS `rehla` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `rehla`;

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `id` int(11) NOT NULL,
  `username` varchar(191) NOT NULL,
  `useremail` varchar(191) NOT NULL,
  `password` varchar(191) NOT NULL,
  `regType` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`id`, `username`, `useremail`, `password`, `regType`) VALUES
(1, 'test', 'test@test.test', '123123', 1),
(2, 'instructor', 'test@test.test', '147852', 2),
(3, 'student', 'test@test.test', '2323123', 3),
(4, 'test', 'test@test.test', '132564', 2),
(5, 'test', 'test@test.test', '132564', 2),
(6, 'mohameed', 'mohameed@email.com', '111111', 2),
(7, 'test', 'test@test.test', '222222', 3);

-- --------------------------------------------------------

--
-- Table structure for table `listen`
--

CREATE TABLE `listen` (
  `id` int(10) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `class` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `vid1` varchar(255) NOT NULL,
  `q1` varchar(255) NOT NULL,
  `a11` varchar(255) NOT NULL,
  `a12` varchar(255) NOT NULL,
  `a13` varchar(255) NOT NULL,
  `q2` varchar(255) NOT NULL,
  `a2` varchar(255) NOT NULL,
  `q3` varchar(255) NOT NULL,
  `a3` varchar(255) NOT NULL,
  `pic1` varchar(255) DEFAULT NULL,
  `txt1` varchar(255) NOT NULL,
  `m1` varchar(255) NOT NULL,
  `m2` varchar(255) NOT NULL,
  `m3` varchar(255) NOT NULL,
  `m4` varchar(255) NOT NULL,
  `m5` varchar(255) NOT NULL,
  `pic2` varchar(255) DEFAULT NULL,
  `txt2` varchar(255) NOT NULL,
  `q4` varchar(255) NOT NULL,
  `a41` varchar(255) NOT NULL,
  `a42` varchar(255) NOT NULL,
  `a43` varchar(255) NOT NULL,
  `q5` varchar(255) NOT NULL,
  `a51` varchar(255) NOT NULL,
  `a52` varchar(255) NOT NULL,
  `a53` varchar(255) NOT NULL,
  `q6` varchar(255) NOT NULL,
  `a61` varchar(255) NOT NULL,
  `a62` varchar(255) NOT NULL,
  `a63` varchar(255) NOT NULL,
  `pic3` varchar(255) DEFAULT NULL,
  `txt3` varchar(255) NOT NULL,
  `stg8` varchar(255) NOT NULL,
  `stg9` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `listen`
--

INSERT INTO `listen` (`id`, `subject`, `class`, `title`, `vid1`, `q1`, `a11`, `a12`, `a13`, `q2`, `a2`, `q3`, `a3`, `pic1`, `txt1`, `m1`, `m2`, `m3`, `m4`, `m5`, `pic2`, `txt2`, `q4`, `a41`, `a42`, `a43`, `q5`, `a51`, `a52`, `a53`, `q6`, `a61`, `a62`, `a63`, `pic3`, `txt3`, `stg8`, `stg9`) VALUES
(1, 'علوم', 'الرابع الابتدائي', 'المخاليط', 'vid1.mp4', 'المخلوط هو خلط مادتان أو أكثر معاً بحيث تحافظ كل منها على نوعها ، أذكر مثال على مخلوط صلب مع صلب تم ذكرة في الفيديو؟', 'المكسرات', 'العصير', 'الماء', 'عند مزج السكر مع الشاي يعتبر محلول ، طبق العملية في منزلك بمساعدة أحد والديك ومن ثم وضح كيف اختفى السكر ؟', 'تحلل السكر في الشاي', 'يعتبر خلط الحليب مع رقائق الذرة مخلوط صلب مع سائل ، بينما خلط السكر مع الشاي هو خلط صلب مع سائل ولكن يطلق عليه محلول وليس مخلوط ، لماذا ؟', 'لأن السكر يذوب في الشاي و رقائق الذرة لا تذوب في الحليب.', '03.pdf', 'الترسيب : وهي ان تنفصل أجزاء المخلوط بعضها عن بعض بسبب اختلاف الكثافة\r\nالترشيح : وهو فصل المادة الصلبة عن السائلة باستخدام مرشح\r\nالمعناطيس : وهو فصل المعادن عن المواد الأخرى باستخدام المغناطيس', '1', '2', '3', '4', '5', '05.pic', '05', '6', '6', '6', '6', '6', '6', '6', '6', '6', '6', '6', '6', '7', '7', '8', '9');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `listen`
--
ALTER TABLE `listen`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `customer`
--
ALTER TABLE `customer`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `listen`
--
ALTER TABLE `listen`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- Database: `sgwm`
--
CREATE DATABASE IF NOT EXISTS `sgwm` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `sgwm`;

-- --------------------------------------------------------

--
-- Table structure for table `activations`
--

CREATE TABLE `activations` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `code` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `completed` tinyint(1) NOT NULL DEFAULT '0',
  `completed_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `activations`
--

INSERT INTO `activations` (`id`, `user_id`, `code`, `completed`, `completed_at`, `created_at`, `updated_at`) VALUES
(1, 1, 'UdeqwKvvOyBNhI14ktrUnyqgT3xuHp2n', 1, '2021-01-21 03:27:21', '2021-01-21 03:27:21', '2021-01-21 03:27:21'),
(2, 2, '0UHTRB9n0HF1945f5jIhUMp8sA3th7gN', 1, '2021-01-21 03:36:26', '2021-01-21 03:36:26', '2021-01-21 03:36:26'),
(3, 3, '3j6VDMKmdOtJxMse3Q2a8qJ6ym8eqiMp', 1, '2021-01-21 04:02:27', '2021-01-21 04:02:27', '2021-01-21 04:02:27'),
(4, 4, 'lmZrxLbIxQarnVOL63TBDcygudbuWnZv', 1, '2021-01-21 04:03:36', '2021-01-21 04:03:36', '2021-01-21 04:03:36'),
(5, 5, '0RskC5Yg52J59KUIajdFZZ29Mk0TIiJ3', 0, NULL, '2021-01-21 04:07:11', '2021-01-21 04:07:11');

-- --------------------------------------------------------

--
-- Table structure for table `dashboard__widgets`
--

CREATE TABLE `dashboard__widgets` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `widgets` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `media__files`
--

CREATE TABLE `media__files` (
  `id` int(10) UNSIGNED NOT NULL,
  `is_folder` tinyint(1) NOT NULL DEFAULT '0',
  `filename` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `path` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `extension` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mimetype` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `filesize` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `folder_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `media__file_translations`
--

CREATE TABLE `media__file_translations` (
  `id` int(10) UNSIGNED NOT NULL,
  `file_id` int(10) UNSIGNED NOT NULL,
  `locale` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `alt_attribute` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `keywords` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `media__imageables`
--

CREATE TABLE `media__imageables` (
  `id` int(10) UNSIGNED NOT NULL,
  `file_id` int(11) NOT NULL,
  `imageable_id` int(11) NOT NULL,
  `imageable_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `zone` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `order` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `menu__menuitems`
--

CREATE TABLE `menu__menuitems` (
  `id` int(10) UNSIGNED NOT NULL,
  `menu_id` int(10) UNSIGNED NOT NULL,
  `page_id` int(10) UNSIGNED DEFAULT NULL,
  `position` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `target` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `link_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'page',
  `class` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `module_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parent_id` int(11) DEFAULT NULL,
  `lft` int(11) DEFAULT NULL,
  `rgt` int(11) DEFAULT NULL,
  `depth` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `is_root` tinyint(1) NOT NULL DEFAULT '0',
  `icon` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `menu__menuitem_translations`
--

CREATE TABLE `menu__menuitem_translations` (
  `id` int(10) UNSIGNED NOT NULL,
  `menuitem_id` int(10) UNSIGNED NOT NULL,
  `locale` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '0',
  `title` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `url` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `uri` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `menu__menus`
--

CREATE TABLE `menu__menus` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `primary` tinyint(4) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `menu__menu_translations`
--

CREATE TABLE `menu__menu_translations` (
  `id` int(10) UNSIGNED NOT NULL,
  `menu_id` int(10) UNSIGNED NOT NULL,
  `locale` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '0',
  `title` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_07_02_230147_migration_cartalyst_sentinel', 1),
(2, '2016_06_24_193447_create_user_tokens_table', 1),
(3, '2014_10_14_200250_create_settings_table', 2),
(4, '2014_10_15_191204_create_setting_translations_table', 2),
(5, '2015_06_18_170048_make_settings_value_text_field', 2),
(6, '2015_10_22_130947_make_settings_name_unique', 2),
(7, '2017_09_17_164631_make_setting_value_nullable', 2),
(8, '2014_11_03_160015_create_menus_table', 3),
(9, '2014_11_03_160138_create_menu-translations_table', 3),
(10, '2014_11_03_160753_create_menuitems_table', 3),
(11, '2014_11_03_160804_create_menuitem_translation_table', 3),
(12, '2014_12_17_185301_add_root_column_to_menus_table', 3),
(13, '2015_09_05_100142_add_icon_column_to_menuitems_table', 3),
(14, '2016_01_26_102307_update_icon_column_on_menuitems_table', 3),
(15, '2016_08_01_142345_add_link_type_colymn_to_menuitems_table', 3),
(16, '2016_08_01_143130_add_class_column_to_menuitems_table', 3),
(17, '2017_09_18_192639_make_title_field_nullable_menu_table', 3),
(18, '2014_10_26_162751_create_files_table', 4),
(19, '2014_10_26_162811_create_file_translations_table', 4),
(20, '2015_02_27_105241_create_image_links_table', 4),
(21, '2015_12_19_143643_add_sortable', 4),
(22, '2017_09_20_144631_add_folders_columns_on_files_table', 4),
(23, '2014_11_30_191858_create_pages_tables', 5),
(24, '2017_10_13_103344_make_status_field_nullable_on_page_translations_table', 5),
(25, '2018_05_23_145242_edit_body_column_nullable', 5),
(26, '2015_04_02_184200_create_widgets_table', 6),
(27, '2013_04_09_062329_create_revisions_table', 7),
(28, '2015_11_20_184604486385_create_translation_translations_table', 7),
(29, '2015_11_20_184604743083_create_translation_translation_translations_table', 7),
(30, '2015_12_01_094031_update_translation_translations_table_with_index', 7),
(31, '2016_07_12_181155032011_create_tag_tags_table', 8),
(32, '2016_07_12_181155289444_create_tag_tag_translations_table', 8);

-- --------------------------------------------------------

--
-- Table structure for table `page__pages`
--

CREATE TABLE `page__pages` (
  `id` int(10) UNSIGNED NOT NULL,
  `is_home` tinyint(1) NOT NULL DEFAULT '0',
  `template` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `page__pages`
--

INSERT INTO `page__pages` (`id`, `is_home`, `template`, `created_at`, `updated_at`) VALUES
(1, 1, 'home', '2021-01-21 03:27:26', '2021-01-21 03:27:26'),
(2, 0, 'default', '2021-01-21 05:35:14', '2021-01-21 05:35:14');

-- --------------------------------------------------------

--
-- Table structure for table `page__page_translations`
--

CREATE TABLE `page__page_translations` (
  `id` int(10) UNSIGNED NOT NULL,
  `page_id` int(10) UNSIGNED NOT NULL,
  `locale` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT '1',
  `body` text COLLATE utf8mb4_unicode_ci,
  `meta_title` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_description` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `og_title` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `og_description` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `og_image` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `og_type` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `page__page_translations`
--

INSERT INTO `page__page_translations` (`id`, `page_id`, `locale`, `title`, `slug`, `status`, `body`, `meta_title`, `meta_description`, `og_title`, `og_description`, `og_image`, `og_type`, `created_at`, `updated_at`) VALUES
(1, 1, 'en', 'Home page', 'home', '1', '<p><strong>You made it!</strong></p>\n<p>You&#39;ve installed AsgardCMS and are ready to proceed to the <a href=\"/en/backend\">administration area</a>.</p>\n<h2>What&#39;s next ?</h2>\n<p>Learn how you can develop modules for AsgardCMS by reading our <a href=\"https://github.com/AsgardCms/Documentation\">documentation</a>.</p>\n', 'Home page', NULL, NULL, NULL, NULL, NULL, '2021-01-21 03:27:26', '2021-01-21 03:27:26'),
(2, 2, 'en', 'Teat Page', '/test', '1', '<h1><strong>Teat Page</strong></h1>\n\n<div id=\"gtx-trans\" style=\"position: absolute; left: 255px; top: 38px;\">\n<div class=\"gtx-trans-icon\">&nbsp;</div>\n</div>', NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-21 05:35:15', '2021-01-21 05:35:15'),
(3, 2, 'ar', 'صفحة تجريبية', '/test', '1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-21 05:35:15', '2021-01-21 05:35:15');

-- --------------------------------------------------------

--
-- Table structure for table `persistences`
--

CREATE TABLE `persistences` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `code` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `persistences`
--

INSERT INTO `persistences` (`id`, `user_id`, `code`, `created_at`, `updated_at`) VALUES
(2, 1, 'p0owLE92qPDG8v4tCtxhbR9tBeyW75JP', '2021-01-21 03:31:26', '2021-01-21 03:31:26'),
(3, 1, 'fEvzEcmTK88RLLNa9IF0uVg0pwDmvk4H', '2021-01-21 03:35:16', '2021-01-21 03:35:16'),
(4, 1, 'BLQMH59ypaQDCwmCm8AT72ZX3sGFTW5j', '2021-01-21 03:35:20', '2021-01-21 03:35:20'),
(5, 1, 'VtHudzgjpjb27eDeDfXv28VHCGAnBzxS', '2021-01-21 03:35:21', '2021-01-21 03:35:21'),
(6, 1, 'twpPrOjNHXghtzkZDlnaIt6qPlYkoVh0', '2021-01-21 03:35:21', '2021-01-21 03:35:21'),
(7, 1, 'wdY9XXoKlKO5G94zc2ukkjHAKlLYKG0F', '2021-01-21 03:36:25', '2021-01-21 03:36:25'),
(8, 1, '5aZ2HKnrEkv3rcJKd40kwnNA7cotwBDq', '2021-01-21 03:36:28', '2021-01-21 03:36:28'),
(9, 1, 'SAWVhpssAKT6bwB8GyYmsJa1zMfQNVuf', '2021-01-21 03:39:31', '2021-01-21 03:39:31'),
(10, 1, 'Y72h9VyDL71q3HHOaQpbmxVccw8cS2ci', '2021-01-21 03:39:38', '2021-01-21 03:39:38'),
(11, 1, '9wq7HAfLJkdokNkmZUykoY10xWbaauhY', '2021-01-21 03:39:38', '2021-01-21 03:39:38'),
(12, 1, 'dXxt5qeIwM6AyKXUSEt8eZcjqZjQr7h3', '2021-01-21 03:39:39', '2021-01-21 03:39:39'),
(13, 1, '0eMofkgR3xxrOroq0dgPXlj2ukhAaIBv', '2021-01-21 04:01:25', '2021-01-21 04:01:25'),
(14, 1, 'eytBE1QypHAXKSnIcYlh61ygwKE5Kcfw', '2021-01-21 04:01:32', '2021-01-21 04:01:32'),
(15, 1, 'Chw35xUUzOCHN7M2aV5fhAVtdJow3wQ0', '2021-01-21 04:01:32', '2021-01-21 04:01:32'),
(16, 1, '5msduaeflpZBHxd3dITKjRI3rIpNa4vP', '2021-01-21 04:01:33', '2021-01-21 04:01:33'),
(17, 1, 'OJ0kW6GyEC0d4fDvfrgsWoA83OQyjitO', '2021-01-21 04:02:26', '2021-01-21 04:02:26'),
(18, 1, 'n0qtxF9Z7BDgkM6dvoIiUazsXLCdtznx', '2021-01-21 04:02:29', '2021-01-21 04:02:29'),
(19, 1, '0hiRZNlrUedihYtqXTgVGqG7cW8Qh4Dy', '2021-01-21 04:02:34', '2021-01-21 04:02:34'),
(20, 1, 'IRieb5uXHgWOJJYA4BTOgWFagfz6jRcM', '2021-01-21 04:02:34', '2021-01-21 04:02:34'),
(21, 1, 'IAuOOktoS4ov4UM1edfvuKUo91BCqYgF', '2021-01-21 04:02:34', '2021-01-21 04:02:34'),
(22, 1, '0GUSA9ly7mENgI3tXxj2efN3PQw8v1Nw', '2021-01-21 04:03:35', '2021-01-21 04:03:35'),
(23, 1, 'GoUevdMIZ834qAxYIt4bWqZGjtD30yZ0', '2021-01-21 04:03:38', '2021-01-21 04:03:38'),
(25, 4, 'nTpqR3boahPtSDK45hwx13GS2WMEhTUj', '2021-01-21 05:15:13', '2021-01-21 05:15:13'),
(26, 4, 'rwqkrp0ebPYQIbnXnwV4P4lDl4BITGk8', '2021-01-21 05:22:07', '2021-01-21 05:22:07'),
(27, 4, '37DQP6K5iMu8oXFmGw6vag94YqtCReo8', '2021-01-21 05:22:15', '2021-01-21 05:22:15'),
(28, 4, 'Bj98UqGSjYOEtHzZdOnPBbWpTjsLJeGV', '2021-01-21 05:35:14', '2021-01-21 05:35:14'),
(29, 4, 'STzXvK6cyOAe5vo8efCgOdFAI9OzBfRL', '2021-01-21 05:35:17', '2021-01-21 05:35:17'),
(30, 4, 'bi60kYARyrgDbinVJEUAGLchWguGSNbR', '2021-01-21 05:35:43', '2021-01-21 05:35:43'),
(31, 4, 'nJpZQhWXqmngO6D2wk3nam4QVbIvTFC8', '2021-01-21 05:36:02', '2021-01-21 05:36:02');

-- --------------------------------------------------------

--
-- Table structure for table `reminders`
--

CREATE TABLE `reminders` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `code` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `completed` tinyint(1) NOT NULL DEFAULT '0',
  `completed_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `reminders`
--

INSERT INTO `reminders` (`id`, `user_id`, `code`, `completed`, `completed_at`, `created_at`, `updated_at`) VALUES
(1, 2, 'WZHGGJ0t4i7O1EiLuah0AmMk5hAlg1u9', 0, NULL, '2021-01-21 04:08:13', '2021-01-21 04:08:13');

-- --------------------------------------------------------

--
-- Table structure for table `revisions`
--

CREATE TABLE `revisions` (
  `id` int(10) UNSIGNED NOT NULL,
  `revisionable_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `revisionable_id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `key` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `old_value` text COLLATE utf8mb4_unicode_ci,
  `new_value` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

CREATE TABLE `roles` (
  `id` int(10) UNSIGNED NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `permissions` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`id`, `slug`, `name`, `permissions`, `created_at`, `updated_at`) VALUES
(1, 'admin', 'Admin', '{\"core.sidebar.group\":true,\"dashboard.index\":true,\"dashboard.update\":true,\"dashboard.reset\":true,\"workshop.sidebar.group\":true,\"workshop.modules.index\":true,\"workshop.modules.show\":true,\"workshop.modules.update\":true,\"workshop.modules.disable\":true,\"workshop.modules.enable\":true,\"workshop.modules.publish\":true,\"workshop.themes.index\":true,\"workshop.themes.show\":true,\"workshop.themes.publish\":true,\"user.roles.index\":true,\"user.roles.create\":true,\"user.roles.edit\":true,\"user.roles.destroy\":true,\"user.users.index\":true,\"user.users.create\":true,\"user.users.edit\":true,\"user.users.destroy\":true,\"account.api-keys.index\":true,\"account.api-keys.create\":true,\"account.api-keys.destroy\":true,\"menu.menus.index\":true,\"menu.menus.create\":true,\"menu.menus.edit\":true,\"menu.menus.destroy\":true,\"menu.menuitems.index\":true,\"menu.menuitems.create\":true,\"menu.menuitems.edit\":true,\"menu.menuitems.destroy\":true,\"media.medias.index\":true,\"media.medias.create\":true,\"media.medias.edit\":true,\"media.medias.destroy\":true,\"media.folders.index\":true,\"media.folders.create\":true,\"media.folders.edit\":true,\"media.folders.destroy\":true,\"setting.settings.index\":true,\"setting.settings.edit\":true,\"page.pages.index\":true,\"page.pages.create\":true,\"page.pages.edit\":true,\"page.pages.destroy\":true,\"translation.translations.index\":true,\"translation.translations.edit\":true,\"translation.translations.export\":true,\"translation.translations.import\":true,\"tag.tags.index\":true,\"tag.tags.create\":true,\"tag.tags.edit\":true,\"tag.tags.destroy\":true}', '2021-01-21 03:26:38', '2021-01-21 03:26:38'),
(2, 'user', 'User', NULL, '2021-01-21 03:26:38', '2021-01-21 03:26:38');

-- --------------------------------------------------------

--
-- Table structure for table `role_users`
--

CREATE TABLE `role_users` (
  `user_id` int(10) UNSIGNED NOT NULL,
  `role_id` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `role_users`
--

INSERT INTO `role_users` (`user_id`, `role_id`, `created_at`, `updated_at`) VALUES
(1, 1, '2021-01-21 03:27:21', '2021-01-21 03:27:21'),
(2, 1, '2021-01-21 03:36:26', '2021-01-21 03:36:26'),
(3, 2, '2021-01-21 04:02:27', '2021-01-21 04:02:27'),
(4, 1, '2021-01-21 04:03:36', '2021-01-21 04:03:36'),
(5, 2, '2021-01-21 04:07:11', '2021-01-21 04:07:11');

-- --------------------------------------------------------

--
-- Table structure for table `setting__settings`
--

CREATE TABLE `setting__settings` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `plainValue` text COLLATE utf8mb4_unicode_ci,
  `isTranslatable` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `setting__settings`
--

INSERT INTO `setting__settings` (`id`, `name`, `plainValue`, `isTranslatable`, `created_at`, `updated_at`) VALUES
(1, 'core::template', 'Flatly', 0, '2021-01-21 03:27:26', '2021-01-21 03:27:26'),
(2, 'core::locales', '[\"en\",\"ar\"]', 0, '2021-01-21 03:27:26', '2021-01-21 05:16:03'),
(3, 'core::site-name', NULL, 1, '2021-01-21 05:16:02', '2021-01-21 05:16:02'),
(4, 'core::site-name-mini', NULL, 1, '2021-01-21 05:16:02', '2021-01-21 05:16:02'),
(5, 'core::site-description', NULL, 1, '2021-01-21 05:16:02', '2021-01-21 05:16:02'),
(6, 'core::analytics-script', NULL, 0, '2021-01-21 05:16:03', '2021-01-21 05:16:03'),
(7, 'dashboard::welcome-title', NULL, 1, '2021-01-21 05:19:00', '2021-01-21 05:19:00'),
(8, 'dashboard::welcome-description', NULL, 1, '2021-01-21 05:19:00', '2021-01-21 05:19:00'),
(9, 'dashboard::welcome-enabled', '1', 0, '2021-01-21 05:19:00', '2021-01-21 05:19:00');

-- --------------------------------------------------------

--
-- Table structure for table `setting__setting_translations`
--

CREATE TABLE `setting__setting_translations` (
  `id` int(10) UNSIGNED NOT NULL,
  `setting_id` int(10) UNSIGNED NOT NULL,
  `locale` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `setting__setting_translations`
--

INSERT INTO `setting__setting_translations` (`id`, `setting_id`, `locale`, `value`, `description`) VALUES
(1, 3, 'en', 'Store Group and Warehouse Management System', NULL),
(2, 4, 'en', 'SGWM', NULL),
(3, 5, 'en', NULL, NULL),
(4, 3, 'ar', 'نظام إدارة مجموعة المتاجر والمستودع', NULL),
(5, 4, 'ar', NULL, NULL),
(6, 5, 'ar', NULL, NULL),
(7, 7, 'en', 'Welcome', NULL),
(8, 7, 'ar', 'أهلا وسهلا', NULL),
(9, 8, 'en', NULL, NULL),
(10, 8, 'ar', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tag__tagged`
--

CREATE TABLE `tag__tagged` (
  `id` int(10) UNSIGNED NOT NULL,
  `taggable_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `taggable_id` int(10) UNSIGNED NOT NULL,
  `tag_id` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tag__tagged`
--

INSERT INTO `tag__tagged` (`id`, `taggable_type`, `taggable_id`, `tag_id`) VALUES
(1, 'Modules\\Page\\Entities\\Page', 2, 1);

-- --------------------------------------------------------

--
-- Table structure for table `tag__tags`
--

CREATE TABLE `tag__tags` (
  `id` int(10) UNSIGNED NOT NULL,
  `namespace` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tag__tags`
--

INSERT INTO `tag__tags` (`id`, `namespace`, `created_at`, `updated_at`) VALUES
(1, 'asgardcms/page', '2021-01-21 05:35:15', '2021-01-21 05:35:15');

-- --------------------------------------------------------

--
-- Table structure for table `tag__tag_translations`
--

CREATE TABLE `tag__tag_translations` (
  `id` int(10) UNSIGNED NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tag_id` int(10) UNSIGNED NOT NULL,
  `locale` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tag__tag_translations`
--

INSERT INTO `tag__tag_translations` (`id`, `slug`, `name`, `tag_id`, `locale`) VALUES
(1, 'test', 'test', 1, 'en');

-- --------------------------------------------------------

--
-- Table structure for table `throttle`
--

CREATE TABLE `throttle` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED DEFAULT NULL,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ip` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `translation__translations`
--

CREATE TABLE `translation__translations` (
  `id` int(10) UNSIGNED NOT NULL,
  `key` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `translation__translation_translations`
--

CREATE TABLE `translation__translation_translations` (
  `id` int(10) UNSIGNED NOT NULL,
  `value` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `translation_id` int(10) UNSIGNED NOT NULL,
  `locale` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `permissions` text COLLATE utf8mb4_unicode_ci,
  `last_login` timestamp NULL DEFAULT NULL,
  `first_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `email`, `password`, `permissions`, `last_login`, `first_name`, `last_name`, `created_at`, `updated_at`) VALUES
(1, 'DevQ@mail.com', '$2y$10$POS9BgkVv02AoeVTAktY/.fGCx7YL5QIbMvdTmwvVI6Im1thzxMgO', NULL, '2021-01-21 04:03:38', 'Dev', 'Q', '2021-01-21 03:27:21', '2021-01-21 04:03:38'),
(2, 'test@test.com', '$2y$10$e6bIw13IL7iK0Ncz6do4N.hOFxDAMXMPs.2PPwAfBA5K48n3AbgT2', '', NULL, 'test', 'test', '2021-01-21 03:36:26', '2021-01-21 03:36:26'),
(3, 'user@sgwm.org', '$2y$10$MUiC4i6a7tyIClF8uwafaOhADNI9jZjdwPm0i8kL7x/Wg5rNLEfq2', '', '2021-01-21 04:04:10', 'user', 'user', '2021-01-21 04:02:27', '2021-01-21 04:04:10'),
(4, 'admin@sgwm.org', '$2y$10$dx18Bw0v76QSfeHpwcRJmeT7QzzyZBdzQPHKbtWv9QpRrCYHJCjjO', '', '2021-01-21 05:36:02', 'admin', 'admin', '2021-01-21 04:03:36', '2021-01-21 05:36:02');

-- --------------------------------------------------------

--
-- Table structure for table `user_tokens`
--

CREATE TABLE `user_tokens` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `access_token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `user_tokens`
--

INSERT INTO `user_tokens` (`id`, `user_id`, `access_token`, `created_at`, `updated_at`) VALUES
(1, 1, 'a53c6dd5-785c-413c-9139-6f1846523a32', '2021-01-21 03:27:22', '2021-01-21 03:27:22'),
(2, 2, 'bcc300e3-0c41-404a-8770-736a07afcc60', '2021-01-21 03:36:26', '2021-01-21 03:36:26'),
(3, 3, '598db848-92bb-4b33-827c-53d46de721dd', '2021-01-21 04:02:27', '2021-01-21 04:02:27'),
(4, 4, 'df8cdd29-fe71-4346-9476-acaca215d9cd', '2021-01-21 04:03:36', '2021-01-21 04:03:36');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `activations`
--
ALTER TABLE `activations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `dashboard__widgets`
--
ALTER TABLE `dashboard__widgets`
  ADD PRIMARY KEY (`id`),
  ADD KEY `dashboard__widgets_user_id_foreign` (`user_id`);

--
-- Indexes for table `media__files`
--
ALTER TABLE `media__files`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `media__file_translations`
--
ALTER TABLE `media__file_translations`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `media__file_translations_file_id_locale_unique` (`file_id`,`locale`),
  ADD KEY `media__file_translations_locale_index` (`locale`);

--
-- Indexes for table `media__imageables`
--
ALTER TABLE `media__imageables`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `menu__menuitems`
--
ALTER TABLE `menu__menuitems`
  ADD PRIMARY KEY (`id`),
  ADD KEY `menu__menuitems_menu_id_foreign` (`menu_id`);

--
-- Indexes for table `menu__menuitem_translations`
--
ALTER TABLE `menu__menuitem_translations`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `menu__menuitem_translations_menuitem_id_locale_unique` (`menuitem_id`,`locale`),
  ADD KEY `menu__menuitem_translations_locale_index` (`locale`);

--
-- Indexes for table `menu__menus`
--
ALTER TABLE `menu__menus`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `menu__menu_translations`
--
ALTER TABLE `menu__menu_translations`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `menu__menu_translations_menu_id_locale_unique` (`menu_id`,`locale`),
  ADD KEY `menu__menu_translations_locale_index` (`locale`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `page__pages`
--
ALTER TABLE `page__pages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `page__page_translations`
--
ALTER TABLE `page__page_translations`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `page__page_translations_page_id_locale_unique` (`page_id`,`locale`),
  ADD KEY `page__page_translations_locale_index` (`locale`);

--
-- Indexes for table `persistences`
--
ALTER TABLE `persistences`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `persistences_code_unique` (`code`);

--
-- Indexes for table `reminders`
--
ALTER TABLE `reminders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `revisions`
--
ALTER TABLE `revisions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `revisions_revisionable_id_revisionable_type_index` (`revisionable_id`,`revisionable_type`);

--
-- Indexes for table `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `roles_slug_unique` (`slug`);

--
-- Indexes for table `role_users`
--
ALTER TABLE `role_users`
  ADD PRIMARY KEY (`user_id`,`role_id`);

--
-- Indexes for table `setting__settings`
--
ALTER TABLE `setting__settings`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `setting__settings_name_unique` (`name`),
  ADD KEY `setting__settings_name_index` (`name`);

--
-- Indexes for table `setting__setting_translations`
--
ALTER TABLE `setting__setting_translations`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `setting__setting_translations_setting_id_locale_unique` (`setting_id`,`locale`),
  ADD KEY `setting__setting_translations_locale_index` (`locale`);

--
-- Indexes for table `tag__tagged`
--
ALTER TABLE `tag__tagged`
  ADD PRIMARY KEY (`id`),
  ADD KEY `tag__tagged_taggable_type_taggable_id_index` (`taggable_type`,`taggable_id`);

--
-- Indexes for table `tag__tags`
--
ALTER TABLE `tag__tags`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tag__tag_translations`
--
ALTER TABLE `tag__tag_translations`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `tag__tag_translations_tag_id_locale_unique` (`tag_id`,`locale`),
  ADD KEY `tag__tag_translations_locale_index` (`locale`);

--
-- Indexes for table `throttle`
--
ALTER TABLE `throttle`
  ADD PRIMARY KEY (`id`),
  ADD KEY `throttle_user_id_index` (`user_id`);

--
-- Indexes for table `translation__translations`
--
ALTER TABLE `translation__translations`
  ADD PRIMARY KEY (`id`),
  ADD KEY `translation__translations_key_index` (`key`);

--
-- Indexes for table `translation__translation_translations`
--
ALTER TABLE `translation__translation_translations`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `translations_trans_id_locale_unique` (`translation_id`,`locale`),
  ADD KEY `translation__translation_translations_locale_index` (`locale`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- Indexes for table `user_tokens`
--
ALTER TABLE `user_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `user_tokens_access_token_unique` (`access_token`),
  ADD KEY `user_tokens_user_id_foreign` (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `activations`
--
ALTER TABLE `activations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `dashboard__widgets`
--
ALTER TABLE `dashboard__widgets`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `media__files`
--
ALTER TABLE `media__files`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `media__file_translations`
--
ALTER TABLE `media__file_translations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `media__imageables`
--
ALTER TABLE `media__imageables`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `menu__menuitems`
--
ALTER TABLE `menu__menuitems`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `menu__menuitem_translations`
--
ALTER TABLE `menu__menuitem_translations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `menu__menus`
--
ALTER TABLE `menu__menus`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `menu__menu_translations`
--
ALTER TABLE `menu__menu_translations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT for table `page__pages`
--
ALTER TABLE `page__pages`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `page__page_translations`
--
ALTER TABLE `page__page_translations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `persistences`
--
ALTER TABLE `persistences`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT for table `reminders`
--
ALTER TABLE `reminders`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `revisions`
--
ALTER TABLE `revisions`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `roles`
--
ALTER TABLE `roles`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `setting__settings`
--
ALTER TABLE `setting__settings`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `setting__setting_translations`
--
ALTER TABLE `setting__setting_translations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `tag__tagged`
--
ALTER TABLE `tag__tagged`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tag__tags`
--
ALTER TABLE `tag__tags`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tag__tag_translations`
--
ALTER TABLE `tag__tag_translations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `throttle`
--
ALTER TABLE `throttle`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `translation__translations`
--
ALTER TABLE `translation__translations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `translation__translation_translations`
--
ALTER TABLE `translation__translation_translations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `user_tokens`
--
ALTER TABLE `user_tokens`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `dashboard__widgets`
--
ALTER TABLE `dashboard__widgets`
  ADD CONSTRAINT `dashboard__widgets_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `media__file_translations`
--
ALTER TABLE `media__file_translations`
  ADD CONSTRAINT `media__file_translations_file_id_foreign` FOREIGN KEY (`file_id`) REFERENCES `media__files` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `menu__menuitems`
--
ALTER TABLE `menu__menuitems`
  ADD CONSTRAINT `menu__menuitems_menu_id_foreign` FOREIGN KEY (`menu_id`) REFERENCES `menu__menus` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `menu__menuitem_translations`
--
ALTER TABLE `menu__menuitem_translations`
  ADD CONSTRAINT `menu__menuitem_translations_menuitem_id_foreign` FOREIGN KEY (`menuitem_id`) REFERENCES `menu__menuitems` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `menu__menu_translations`
--
ALTER TABLE `menu__menu_translations`
  ADD CONSTRAINT `menu__menu_translations_menu_id_foreign` FOREIGN KEY (`menu_id`) REFERENCES `menu__menus` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `page__page_translations`
--
ALTER TABLE `page__page_translations`
  ADD CONSTRAINT `page__page_translations_page_id_foreign` FOREIGN KEY (`page_id`) REFERENCES `page__pages` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `setting__setting_translations`
--
ALTER TABLE `setting__setting_translations`
  ADD CONSTRAINT `setting__setting_translations_setting_id_foreign` FOREIGN KEY (`setting_id`) REFERENCES `setting__settings` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `tag__tag_translations`
--
ALTER TABLE `tag__tag_translations`
  ADD CONSTRAINT `tag__tag_translations_tag_id_foreign` FOREIGN KEY (`tag_id`) REFERENCES `tag__tags` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `translation__translation_translations`
--
ALTER TABLE `translation__translation_translations`
  ADD CONSTRAINT `translation__translation_translations_translation_id_foreign` FOREIGN KEY (`translation_id`) REFERENCES `translation__translations` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `user_tokens`
--
ALTER TABLE `user_tokens`
  ADD CONSTRAINT `user_tokens_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;
--
-- Database: `vurs`
--
CREATE DATABASE IF NOT EXISTS `vurs` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `vurs`;

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2019_08_19_000000_create_failed_jobs_table', 1),
(4, '2021_01_13_102056_create_posts_table', 1);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `posts`
--

CREATE TABLE `posts` (
  `id` int(10) UNSIGNED NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `body` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `user_request`
--

CREATE TABLE `user_request` (
  `id` int(11) NOT NULL,
  `fname` varchar(191) NOT NULL,
  `mname` varchar(191) NOT NULL,
  `lname` varchar(191) NOT NULL,
  `nationality` varchar(191) NOT NULL,
  `DOB` date NOT NULL,
  `city` varchar(191) NOT NULL,
  `address` varchar(191) NOT NULL,
  `phone` int(11) NOT NULL,
  `email` varchar(191) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `user_request`
--

INSERT INTO `user_request` (`id`, `fname`, `mname`, `lname`, `nationality`, `DOB`, `city`, `address`, `phone`, `email`) VALUES
(2, 'a', 'a', 'a', 'a', '2021-01-02', 'Makkah', 'Al-Hajj ST. Makkah, SA', 567747272, 'qarinet.01@gmail.com'),
(3, 'a', 'a', 'a', 'a', '2021-01-02', 'Makkah', 'Al-Hajj ST. Makkah, SA', 567747272, 'qarinet.01@gmail.com'),
(4, 'a', 'a', 'a66', 'a', '2021-01-06', 'Makkah', 'Al-Hajj ST. Makkah, SA', 567747272, 'qarinet.01@gmail.com'),
(5, 'dsfs', 'sfds', 'sdf', 'sdf', '2021-01-05', 'dsf', 'f', 5556, 'sdf@esde'),
(6, 'test', 'testo', 'testa', 'testy', '2021-01-13', 'Makkah', 'Al-Hajj ST. Makkah, SA', 567747272, 'test@test.com'),
(7, 'test', 'test', 'test', 'test', '2021-01-05', 'makkah', 'الحج', 566478895, 'test@test.com');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `posts`
--
ALTER TABLE `posts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- Indexes for table `user_request`
--
ALTER TABLE `user_request`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `posts`
--
ALTER TABLE `posts`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `user_request`
--
ALTER TABLE `user_request`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
